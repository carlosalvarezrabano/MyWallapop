package com.uniovi.sdientrega193.repositories;

import com.uniovi.sdientrega193.entities.Friendship;
import com.uniovi.sdientrega193.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface FriendshipRepository extends CrudRepository<Friendship, Long> {

    @Query("SELECT f FROM Friendship f where f.left = ?1 OR f.right = ?1")
    Page<Friendship> findByUser(Pageable pageable, User user);

    @Query("SELECT f FROM Friendship f where f.left = ?1 OR f.right = ?1")
    List<Friendship> findByUser(User user);

    @Modifying
    @Transactional
    @Query("DELETE FROM Friendship f WHERE f.left.id=?1 OR f.right.id=?1")
    void removeAllByUserId(long id);

    @Query("select f from Friendship f where f.left=?1 AND f.right=?2 OR f.left=?2 and f.right=?1")
    Optional<Friendship> findByUsers(User left, User right);

    @Query("select f from Friendship f where f.left=?1 or f.right=?1")
    ArrayList<Friendship> findFriendsByUser(User user);

    @Override
    Friendship save(Friendship friendship);
}
