package com.uniovi.sdientrega193.repositories;

import com.uniovi.sdientrega193.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.List;

import static org.hibernate.loader.Loader.SELECT;

public interface UsersRepository extends CrudRepository<User, Long> {

    User findByEmail(String email);
    Page<User> findAll(Pageable pageable);
    List<User> findAll();

    @Query("SELECT s from User s where s.email <> 'admin@email.com' AND s.email <> ?1")
    Page<User> findAllLessAdmin(Pageable pageable, String email);

    @Query("SELECT s from User s where s.email <> 'admin@email.com' AND s.email <> ?1 AND " +
            "(lower(s.email) like lower(?2) or lower(s.name) like lower (?2)" +
            "or lower(s.lastName) like lower(?2))")
    Page<User> findAllLessAdminBySearchText(Pageable pageable, String email, String searchText);

    @Query("SELECT s from User s where (lower(s.email) like lower(?1) or lower(s.name) like lower (?1)" +
            "or lower(s.lastName) like lower(?1))")
    Page<User> findAllBySearchText(Pageable pageable, String searchText);

    @Query("SELECT s.friends from User s where s.id = ?1")
    Page<User> getFriends(Pageable pageable, long id);

    Long findByName(String name);

}
