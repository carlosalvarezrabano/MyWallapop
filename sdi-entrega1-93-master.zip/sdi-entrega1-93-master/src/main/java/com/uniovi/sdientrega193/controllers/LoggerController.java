package com.uniovi.sdientrega193.controllers;


import com.uniovi.sdientrega193.services.LoggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoggerController {

    @Autowired
    private LoggerService loggerService;


    /**
     * Controlador para listar los logs
     * @param model
     * @param searchText
     * @return la vista /log/list
     */
    @RequestMapping(value = "/log/list")
    public String listLogs(Model model, @RequestParam(value="", required=false) String searchText) {
        if (searchText==null)
            model.addAttribute("logs", loggerService.findAll());
        else
            model.addAttribute("logs", loggerService.findAllBy(searchText));
        return "/log/list";
    }


    /**
     * Controlador para eliminar los logs
     * @return la vista log/list
     */
    @RequestMapping(value = "/log/delete")
    public String deleteLogs() {
        loggerService.deleteAll();
        return "/log/list";
    }
}
