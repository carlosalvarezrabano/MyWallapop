package com.uniovi.sdientrega193.controllers;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.services.*;
import com.uniovi.sdientrega193.validators.SignUpFormValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    private SignUpFormValidator signUpFormValidator;
    @Autowired
    private UsersService usersService;
    @Autowired
    private SecurityService securityService;
    @Autowired
    private RolesService rolesService;

    @Autowired
    private FriendRequestService friendRequestService;

    @Autowired
    private  FriendshipService   friendshipService;

    @Autowired
    private LoggerService loggerService;


    /**
     * Controlador get para registrarse
     * @param model
     * @return la vista signup
     */
    @RequestMapping(value = "/signup", method = RequestMethod.GET)
    public String signup(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }

    /**
     * Controlador post para registrarse
     * @param user
     * @param result
     * @return la vista signup
     */
    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public String signup(@Validated User user,BindingResult result){
        signUpFormValidator.validate(user,result);
        if(result.hasErrors()){
            return "signup";
        }
        user.setRole(rolesService.getRoles()[0]);
        usersService.addUser(user);
        securityService.autoLogin(user.getEmail(), user.getPasswordConfirm());
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método POST con mapping /signup"));
        return "redirect:home";
    }


    /**
     * Controlador para iniciar sesión
     * @param model
     * @param error
     * @param logout
     * @return la vista /login
     */
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(Model model,String error, String logout) {
        if (error != null) {
            model.addAttribute("error", "Your username and password is invalid.");

        }
        if (logout != null) {
            model.addAttribute("message", "You have been logged out successfully.");
            Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Log-out");
            loggerService.addLog(new Log("LOGOUT", new Timestamp(System.currentTimeMillis()),
                    "Username: " + "anónimo"));
        }


        return "login";
    }


    /**
     * Controlador de la vista home
     * @return la vista /home
     */
    @RequestMapping(value = { "/home" }, method = RequestMethod.GET)
    public String home() {
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Volver a la página principals");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /home"));
        return "home";
    }


    /**
     * Controlador para de listar usuarios
     * @param model
     * @param pageable
     * @param searchText
     * @return la vista user/list
     */
    @RequestMapping("/user/list")
    public String getListado(Model model, Pageable pageable,
                             @RequestParam(value="", required=false) String searchText) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User activeUser = usersService.getUserByEmail(email);

        model.addAttribute("misAmigosEmail", friendshipService.getFriendsEmailByUserLogin());
        model.addAttribute("misSolicitudes", friendRequestService.findEmailSolicitadoByEmail(email));

        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Listar usuarios");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /user/list"));


        if(activeUser.getRole().equals("ROLE_ADMIN")){
            model.addAttribute("usersList", usersService.getUsers());
            return "user/adminList";
        }else{
            Page<User> users = usersService.getUsers(pageable, searchText);
            model.addAttribute("page", users);
            model.addAttribute("usersList", users.getContent());
            return "user/list";
        }


    }


    /**
     * Controlador para borrar usuarios como admin pasando los usuarios por url
     * @param users
     * @return la tabla de user/adminList
     */
    @RequestMapping("/user/delete/{users}")
    public String getUserToDelete(@PathVariable String users){
        String[] ids = users.split(",");
        usersService.deleteUsers(ids);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Borrar usuario");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /user/delete/{users} y parámetro String (users)"));
        return "user/adminList :: table";
    }


    /**
     * Controlador para actualizar la tabla de listar usuarios como admin
     * @param model
     * @return la tabla de user/adminList
     */
    @RequestMapping("/user/list/update")
    public String updateList(Model model){
        List<User> users = usersService.getUsers();
        model.addAttribute("usersList", users);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Actualizar el listado de usuarios");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /user/list/update"));
        return "user/adminList :: table";
    }


}
