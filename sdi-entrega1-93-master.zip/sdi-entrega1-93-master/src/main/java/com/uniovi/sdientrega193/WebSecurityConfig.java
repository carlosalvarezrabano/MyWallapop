package com.uniovi.sdientrega193;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.services.LoggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.thymeleaf.extras.springsecurity4.dialect.SpringSecurityDialect;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private LoggerService loggerService;

    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .authorizeRequests()
                .antMatchers("/css/**", "/images/**", "/script/**", "/", "/signup", "/login/**").permitAll()
                .antMatchers("/user/delete").hasAuthority("ROLE_ADMIN")
                .antMatchers("/user/adminList").hasAuthority("ROLE_ADMIN")
                .antMatchers("/user/**").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .antMatchers("/friendship/postslist/*").hasAnyAuthority("ROLE_USER")
                .antMatchers("/friendship/**").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .antMatchers("/post/adminList").hasAuthority("ROLE_ADMIN")
                .antMatchers("/post/adminList/search").hasAuthority("ROLE_ADMIN")
                .antMatchers("/post/add").hasAuthority("ROLE_USER")
                .antMatchers("/post/list").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .antMatchers("/log/*").hasAnyAuthority("ROLE_ADMIN")
                .antMatchers("/friendRequest/list").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .antMatchers("/friendRequest/**").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .antMatchers("/home").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .and()
                .formLogin()
                .loginPage("/login")
                .permitAll()
                .defaultSuccessUrl("/user/list")
                .and()
                .logout()
                .permitAll();
    }

    @Bean
    public SpringSecurityDialect securityDialect() {
        return new SpringSecurityDialect();
    }

}
