package com.uniovi.sdientrega193.validators;

import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.services.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class SignUpFormValidator implements Validator {
    @Autowired
    private UsersService usersService;
    @Override
    public boolean supports(Class<?> aClass) {
        return User.class.equals(aClass);
    }
    @Override
    public void validate(Object target, Errors errors) {
        User user = (User) target;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "Error.signup.email.empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "Error.signup.name.empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "Error.signup.lastname.empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "Error.signup.password.empty");

        if (usersService.getUserByEmail(user.getEmail()) != null) {
            errors.rejectValue("email", "Error.signup.email.duplicate");}

        if (!user.getPasswordConfirm().equals(user.getPassword())) {
            errors.rejectValue("passwordConfirm",
                    "Error.signup.passwordConfirm.coincidence");}
    }
}

