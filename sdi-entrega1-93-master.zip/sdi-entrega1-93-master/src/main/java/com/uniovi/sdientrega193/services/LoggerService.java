package com.uniovi.sdientrega193.services;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.repositories.LoggerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoggerService {

    @Autowired
    private LoggerRepository loggerRepository;

    /**
     * Añade un log a la BD
     * @param logger
     */
    public void addLog(Log logger) {
        loggerRepository.save(logger);
    }

    /**
     * Encuentra todos los logs de la BD
     * @return List<Log>
     */
    public List<Log> findAll() {
        return loggerRepository.findAll();
    }

    /**
     * Borra todos los logs de la BD
     */
    public void deleteAll()  { loggerRepository.deleteAll();}

    /**
     * Devuelve la lista de logs con el tipo recibido por parametros
     * @return List<Log>
     */
    public List<Log> findAllBy(String searchText) {
        return loggerRepository.findAllBy(searchText);
    }
}
