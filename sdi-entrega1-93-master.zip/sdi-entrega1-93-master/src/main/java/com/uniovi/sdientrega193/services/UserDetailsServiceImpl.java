package com.uniovi.sdientrega193.services;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

@Service("userDetailsService")
public class UserDetailsServiceImpl implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private LoggerService loggerService;

    /**
     * Carga un usuario y lo logea recibiendo su email
     * @param email
     * @return UserDetails
     * @throws UsernameNotFoundException
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = usersRepository.findByEmail(email);
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        if (user == null) {
            Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Usuario y contraseña inválidos al logearse");
            loggerService.addLog(new Log("LOGIN-ERR", new Timestamp(System.currentTimeMillis()),
                    "Username: " + email));
            throw new UsernameNotFoundException(email);
        }
        grantedAuthorities.add(new SimpleGrantedAuthority(user.getRole()));

        UserDetails u = new org.springframework.security.core.userdetails.User(
                user.getEmail(), user.getPassword(), grantedAuthorities);
        if (u != null) {
            Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Logearse correctamente");
            loggerService.addLog(new Log("LOG-EX", new Timestamp(System.currentTimeMillis()),
                    "Username: " + email));
        }
        return u;
    }
}
