package com.uniovi.sdientrega193.services;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.uniovi.sdientrega193.entities.FriendRequest;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.repositories.FriendRequestsRepository;
import com.uniovi.sdientrega193.repositories.FriendshipRepository;
import com.uniovi.sdientrega193.repositories.PostsRepository;
import com.uniovi.sdientrega193.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@Service
public class UsersService {

    @Autowired
    private FriendRequestsRepository friendRequestsRepository;
    @Autowired
    private PostsRepository postsRepository;
    @Autowired
    private FriendshipRepository friendshipRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * Devuelve una pagina de todos los usuarios del sistema
     * @param pageable
     * @return Page<User>
     */
    public Page<User> getUsers(Pageable pageable) {
        return usersRepository.findAll(pageable);
    }

    /**
     * Devuelve la lista con todos los usuarios del sistema
     * @return List<User>
     */
    public List<User> getUsers() {
        return usersRepository.findAll();
    }

    /**
     * Devuelve una página con los usuarios que validan la consulta recibida por parámetros
     * @param pageable
     * @param searchText
     * @return Page<User>
     */
    public Page<User> getUsersBySearchText(Pageable pageable, String searchText) {
        searchText = "%"+searchText+"%";
        return usersRepository.findAllBySearchText(pageable, searchText);
    }

    /**
     * Devuelve un usuario dada su id
     * @param id
     * @return User
     */
    public User getUserById(Long id){
        return usersRepository.findById(id).stream().findFirst().orElse(null);
    }

    /**
     * Devuelve una página con usuarios del sistema exceptuando el usuario administrador y
     * al propio usuario autenticado
     * @param u
     * @param pageable
     * @return Page<User>
     */
    public Page<User> getUsersLessAdmin(User u, Pageable pageable) {
        Page<User> users = usersRepository.findAllLessAdmin(pageable,u.getEmail());
        return users;
    }

    /**
     * Devuelve una página con usuarios del sistema que cumplen la consulta exceptuando el usuario administrador y
     * al propio usuario autenticado
     * @param u
     * @param pageable
     * @param searchText
     * @return
     */
    public Page<User> getUsersLessAdminBySearchText(User u, Pageable pageable, String searchText) {
        searchText = "%"+searchText+"%";
        Page<User> users = usersRepository.findAllLessAdminBySearchText(pageable,u.getEmail(), searchText);
        return users;
    }

    /**
     * Añade un usuario
     * @param user
     */
    public void addUser(User user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        usersRepository.save(user);
    }

    /**
     * Devuelve un usuario dado su email
     * @param dni
     * @return User
     */
    public User getUserByEmail(String dni) {
        return usersRepository.findByEmail(dni);
    }

    /**
     * Borra un usuario de la base de datos
     * @param id
     */
    public void deleteUser(Long id) {
        usersRepository.deleteById(id);
    }

    /**
     * Borra todos los usuarios recibidos como parametros
     * @param ids
     */
    public void deleteUsers(String[] ids){
        for(String  id : ids) {
            User u = usersRepository.findById(Long.parseLong(id)).get();
            friendshipRepository.removeAllByUserId(u.getId());
            postsRepository.removeByUser(u.getId());
            friendRequestsRepository.removeAllByUserId(u.getId());
            usersRepository.deleteById(Long.parseLong(id));
        }
    }

    /**
     * Devueve los usuarios que coinciden con la consulta
     * @param pageable
     * @param searchText
     * @return Page<User>
     */
    public Page<User> getUsers(Pageable pageable, String searchText){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User activeUser = getUserByEmail(email);
        Page<User> users;
        if (searchText != null && !searchText.isEmpty()){
            if (activeUser.getRole().equals("ROLE_ADMIN"))
                users = getUsersBySearchText(pageable, searchText);
            else
                users = getUsersLessAdminBySearchText(activeUser, pageable, searchText);
        }
        else {
            if (activeUser.getRole().equals("ROLE_ADMIN"))
                users = getUsers(pageable);
            else
                users = getUsersLessAdmin(activeUser, pageable);
        }
        return users;
    }

    /**
     * Comprueba si el usuario que está autenticado es el administrador
     * @return boolean
     */
    public boolean checkIfAdmin(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User activeUser = getUserByEmail(email);
        if(activeUser.getEmail().equals("admin@email.com"))
            return true;
        return false;
    }
}
