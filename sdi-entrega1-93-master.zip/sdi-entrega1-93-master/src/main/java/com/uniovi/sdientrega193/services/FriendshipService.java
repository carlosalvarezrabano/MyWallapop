package com.uniovi.sdientrega193.services;

import com.uniovi.sdientrega193.entities.Friendship;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.repositories.FriendshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class FriendshipService {

    @Autowired
    private FriendshipRepository friendshipRepo;
    @Autowired
    private UsersService usersService;

    /**
     * Devuelve una pagina con las amistades de un usuario recibido por parametros
     * @param pageable
     * @param u
     * @return Page<Friendship>
     */
    public Page<Friendship> getFriendshipsByUser(Pageable pageable, User u){
        return friendshipRepo.findByUser(pageable, u);
    }

    /**
     * Devuelve los usuarios amigos del usuario autenticado
     * @param pageable
     * @return Page<User>
     */
    public Page<User> getFriendsByUser(Pageable pageable){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = usersService.getUserByEmail(email);
        LinkedList<User> res = new LinkedList<>();
        for(Friendship f : getFriendshipsByUser(pageable, user)){
            if(f.getLeft().getId() == user.getId())
                res.add(f.getRight());
            else
                res.add(f.getLeft());
        }
        return new PageImpl<>(res);
    }

    /**
     * Devuelve una lista con todos los amigos del usuario autenticado
     * @return List<User>
     */
    public List<User> getAllFriendsByUser(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = usersService.getUserByEmail(email);
        List<User> res = new ArrayList<>();
        for(Friendship f : friendshipRepo.findByUser(user)){
            if(f.getLeft().getId() == user.getId())
                res.add(f.getRight());
            else
                res.add(f.getLeft());
        }
        return res;
    }

    /**
     * Devuelve una lista con todos los amigos del usuario autenticado
     * @return ArrayList<User>
     */
    public ArrayList<Friendship> getFriendsByUserLogin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User user = usersService.getUserByEmail(email);
        if (friendshipRepo.findFriendsByUser(user)!=null) {
            return friendshipRepo.findFriendsByUser(user);
        }
        else {
            return new ArrayList<Friendship>();
        }
    }

    /**
     * Devuelve el email de los amigos del usuario autenticado
     * @return ArrayList<String>
     */
    public ArrayList<String> getFriendsEmailByUserLogin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();

        ArrayList<String> lista  = new ArrayList<String>();
        for(var fs: getFriendsByUserLogin()) {
            if (fs.getRight().getEmail().equals(email)) lista.add(fs.getLeft().getEmail());
            else lista.add(fs.getRight().getEmail());
        }
        return lista;
    }
}
