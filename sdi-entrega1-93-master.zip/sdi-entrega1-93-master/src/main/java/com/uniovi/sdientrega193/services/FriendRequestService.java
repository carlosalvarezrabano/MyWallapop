package com.uniovi.sdientrega193.services;

import com.uniovi.sdientrega193.entities.FriendRequest;
import com.uniovi.sdientrega193.entities.Friendship;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.repositories.FriendRequestsRepository;
import com.uniovi.sdientrega193.repositories.FriendshipRepository;
import com.uniovi.sdientrega193.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.*;

@Service
public class FriendRequestService {

    @Autowired
    private FriendRequestsRepository friendRequestsRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private FriendshipRepository friendshipRepository;

    @Autowired
    private UsersService usersService;

    @Autowired
    private SecurityService securityService;

    private final HttpSession httpSession;

    public FriendRequestService(HttpSession httpSession) {
        this.httpSession = httpSession;
    }

    /**
     * Recibe el id del usuario alque le manda la solicitud y crea una solicitud de amistad
     * @param id_recoge
     */
    public void addFriendRequest(Long id_recoge) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User activeUser = usersService.getUserByEmail(email);
        if (friendRequestsRepository.findByIds(activeUser.getId(), id_recoge).isEmpty()) {
            User user_envia  = usersRepository.findById(activeUser.getId()).get();
            User user_recoge = usersRepository.findById(id_recoge).get();
            friendRequestsRepository.save(new FriendRequest(user_envia, user_recoge));
        }


    }

    /**
     * Recibe el id de un usuario y comprueba si es amigo del usuario autenticado
     * @param id_recoge
     * @return boolean
     */
    public boolean alreadyFriends(Long id_recoge) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        User activeUser = usersService.getUserByEmail(email);
        if (friendshipRepository.findByUsers(activeUser, usersRepository.findById(id_recoge).get()).isPresent()
                ||   friendshipRepository.findByUsers(usersRepository.findById(id_recoge).get(),activeUser ).isPresent()){
            return true;
        }
        return false;
    }

    /**
     * Devuelve una lista de peticiones de amistad del usurio cuyo email
     * se recibe por parametros
     * @param email
     * @return List<FriendRequest>
     */
    public List<FriendRequest> findByEmail(String email) {
        return friendRequestsRepository.findByEmail(email);
    }

    /**
     * Devuelve una lista con el email del receptor de las solicitudes en
     * las que el email recibido por parametros es el emisor
     * @param email
     * @return List<String>
     */
    public List<String> findEmailSolicitadoByEmail(String email) {
        List<String> l = new ArrayList<>();
        for (var friendRequest: findByEmail(email)) {
            l.add(friendRequest.getreceiver().getEmail());
        }
        return l;
    }

    /**
     * Devuelve las peticiones de amistad que tiene un usuario
     * @param pageable
     * @param user
     * @return Page<FriendRequest>
     */
    public Page<FriendRequest> getRequestsForUser(Pageable pageable, User user) {
        Page<FriendRequest> requests = new PageImpl<FriendRequest>(new LinkedList<FriendRequest>());
        if (user.getRole().equals("ROLE_USER")) {
            requests = friendRequestsRepository.findAllByUser(pageable, user);}
        return requests;
    }

    /**
     * Acepta la petición de amistad cuyo id se recibe por parametros
     * @param id
     */
    public void accept(Long id) {
        Optional<FriendRequest> request = friendRequestsRepository.findById(id);
        if(request.isPresent()) {
            User user1 = request.get().getSender();
            User user2 = request.get().getreceiver();
            Friendship friendship = new Friendship(user1, user2);
            friendshipRepository.save(friendship);
            friendRequestsRepository.deleteById(id);
            Optional<FriendRequest> request2 = friendRequestsRepository.findByIds(user2.getId(), user1.getId());
            if(request2.isPresent())    {
                friendRequestsRepository.deleteById(request2.get().id);
            }
        }
    }

    /**
     * Rechaza la petición de amistad cuyo id se recibe por parametros
     * @param id
     */
    public void reject(Long id) {
        Optional<FriendRequest> request = friendRequestsRepository.findById(id);
        if(request.isPresent()) {
            friendRequestsRepository.deleteById(id);
        }
    }

}
