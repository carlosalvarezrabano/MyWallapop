package com.uniovi.sdientrega193.services;

import org.springframework.stereotype.Service;

@Service
public class RolesService {
    String[] roles = {"ROLE_USER", "ROLE_ADMIN"};

    /**
     * Devuelve el array de roles
     * @return String[]
     */
    public String[] getRoles() {
        return roles;
    }
}
