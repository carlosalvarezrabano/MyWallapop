package com.uniovi.sdientrega193;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdiEntrega193Application {

    public static void main(String[] args) {
        SpringApplication.run(SdiEntrega193Application.class, args);
    }

}
