package com.uniovi.sdientrega193.services;

import com.uniovi.sdientrega193.entities.Post;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.repositories.PostsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Service
public class PostService {

    @Autowired
    private PostsRepository postsRepository;

    /**
     * Devuelve los posts del usuario que está autenticado
     * @param pageable
     * @param user
     * @return Page<Post>
     */
    public Page<Post> getMyPosts(Pageable pageable, User user) {
        return postsRepository.findAllMyPosts(pageable, user);
    }

    /**
     * Devuelve los posts del usuario autenticado para ser vistos por sus amigos
     * @param pageable
     * @param user
     * @return Page<Post>
     */
    public Page<Post> getMyPostsForFriends(Pageable pageable, User user) {
        return postsRepository.findAllMyPostsForFriends(pageable, user);
    }

    /**
     * Devuelve una pagina de todos los posts del sistema
     * @param pageable
     * @return Page<Post>
     */
    public Page<Post> getAllPosts(Pageable pageable){
        return postsRepository.findAll(pageable);
    }

    /**
     * Añade un nuevo post
     * @param post
     * @param u
     */
    public void addPost(Post post, User u) {
        post.setUser(u);
        post.setDate(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES));
        post.setState("aceptado");
        postsRepository.save(post);
    }

    /**
     * Cambia el estado del post cuya id se recibe por parámetro
     * @param state
     * @param id
     */
    public void setState(String state, long id){
        postsRepository.setState(state, id);
    }

    /**
     * Devuelve una página con los post que coinciden con la consulta
     * @param pageable
     * @param query
     * @return Page<Post>
     */
    public Page<Post> getPostsByQuery(Pageable pageable, String query) {
        query = "%"+query+"%";
        return postsRepository.findPostsByQueryText(pageable,query);
    }
}
