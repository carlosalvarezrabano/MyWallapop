package com.uniovi.sdientrega193.controllers;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.entities.Post;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.services.FriendshipService;
import com.uniovi.sdientrega193.services.LoggerService;
import com.uniovi.sdientrega193.services.PostService;
import com.uniovi.sdientrega193.services.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.Timestamp;
import java.util.List;

@Controller
public class FriendshipController {

    @Autowired
    private FriendshipService friendshipService;
    @Autowired
    private UsersService usersService;
    @Autowired
    private PostService postService;
    @Autowired
    private LoggerService loggerService;


    /**
     * Controlador para la lista de amigos
     * @param model
     * @param pageable
     * @return la vista friendship/list
     */
    @RequestMapping("/friendship/list")
    public String getListFriends(Model model, Pageable pageable){
        Page<User> friends = friendshipService.getFriendsByUser(pageable);
        model.addAttribute("page", friends);
        model.addAttribute("usersList", friends.getContent());
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Listar amistades");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /friendship/list"));
        return "friendship/list";
    }


    /**
     * Controlador para listar las publicaciones de un amigo dado el id por url
     * @param model
     * @param pageable
     * @param id
     * @return la vista /friendship/postslist
     */
    @RequestMapping("/friendship/postslist/{id}")
    public String getPostListFriends(Model model, Pageable pageable, @PathVariable Long id){
        List<User> friends = friendshipService.getAllFriendsByUser();
        User u = usersService.getUserById(id);
        Page<Post> friendPosts;
        if(u == null || !friends.contains(u)) {
            return "redirect:/friendship/list";
        }
        else {
            friendPosts = postService.getMyPostsForFriends(pageable, u);
        }
        model.addAttribute("friend", u.getEmail());
        model.addAttribute("page", friendPosts);
        model.addAttribute("user_id", id);
        model.addAttribute("friendPostsList", friendPosts.getContent());
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Listar amistades");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /friendship/postslist/{id} con parámetro id del usuario"));
        return "friendship/postslist";
    }
}
