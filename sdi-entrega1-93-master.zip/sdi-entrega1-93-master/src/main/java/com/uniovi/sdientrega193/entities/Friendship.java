package com.uniovi.sdientrega193.entities;

import javax.persistence.*;

@Entity
public class Friendship {

    @Id
    @GeneratedValue
    private long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User left;

    @ManyToOne
    @JoinColumn(name = "friend_id")
    private User right;

    public Friendship(){}

    public Friendship(User left, User right){
        this.left= left;
        this.right = right;
    }

    @Override
    public String toString() {
        return "FriendShip{" +
                "id=" + id +
                ", left=" + left +
                ", right=" + right +
                '}';
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setLeft(User left) {
        this.left = left;
    }

    public void setRight(User right) {
        this.right = right;
    }

    public long getId() {
        return id;
    }

    public User getLeft() {
        return left;
    }

    public User getRight() {
        return right;
    }
}
