package com.uniovi.sdientrega193.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

    /**
     * Controlador del home
     * @return vista index
     */
    @RequestMapping("/")
    public String index() {
        return "index";
    }
}
