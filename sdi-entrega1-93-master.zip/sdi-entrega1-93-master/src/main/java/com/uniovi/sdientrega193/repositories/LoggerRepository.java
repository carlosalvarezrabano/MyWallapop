package com.uniovi.sdientrega193.repositories;
import com.uniovi.sdientrega193.entities.Log;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface LoggerRepository extends CrudRepository<Log, Long> {


    Log save(Log logger);

    @Query("select l from Log l order by l.date desc ")
    List<Log> findAll();

    @Query("select l from Log l where l.type like ?1 order by l.date desc")
    List<Log> findAllBy(String searchText);
}
