package com.uniovi.sdientrega193.entities;

import javax.persistence.*;

@Entity
public class FriendRequest {

    @Id
    @GeneratedValue
    public Long id;

    @ManyToOne
    @JoinColumn(name = "sender_id")
    private User sender;

    @ManyToOne
    @JoinColumn(name = "receiver_id")
    private User receiver;

    public FriendRequest(){}
    public FriendRequest(User sender, User receiver){
        this.sender = sender;
        this.receiver = receiver;
    }

    public User getSender() {
        return sender;
    }
    public User getreceiver() {
        return receiver;
    }
    public void setSender(User sender) {
        this.sender = sender;
    }
    public void setreceiver(User receiver) {
        this.receiver = receiver;
    }

    @Override
    public String toString() {
        return "FriendRequest{" +
                "id=" + id +
                '}';
    }
}
