package com.uniovi.sdientrega193.repositories;

import com.uniovi.sdientrega193.entities.FriendRequest;
import com.uniovi.sdientrega193.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

public interface FriendRequestsRepository extends CrudRepository<FriendRequest, Long> {

    @Modifying
    @Transactional
    @Query("DELETE FROM FriendRequest f WHERE f.sender.id=?1 OR f.receiver.id=?1")
    void removeAllByUserId(long id);

    FriendRequest save(FriendRequest friendRequest);

    @Query("SELECT f FROM FriendRequest f WHERE f.sender.id=?1 AND f.receiver.id=?2")
    Optional<FriendRequest> findByIds(Long id_envia, Long id_recoge);

    @Query("SELECT f FROM FriendRequest f WHERE f.sender.email=?1")
    List<FriendRequest> findByEmail(String email);

    @Query("SELECT r FROM FriendRequest r WHERE r.receiver = ?1 ORDER BY r.id ASC")
    Page<FriendRequest> findAllByUser(Pageable pageable, User user);

    @Query("SELECT f FROM FriendRequest f WHERE f.id=?1")
    Optional<FriendRequest> findById(Long id);

    @Query("DELETE FROM FriendRequest f WHERE f.sender.id=?1 AND f.receiver.id=?2")
    void removeBetweenUsers(long id1, long id2);

}
