package com.uniovi.sdientrega193.entities;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
public class Post {
    @Id
    @GeneratedValue
    private Long id;
    private LocalDateTime date;
    private String title;
    private String description;
    private String state;

    @ManyToOne
    @JoinColumn(name="user_id")
    private User user;

    public Post() {}

    public Post(User user, LocalDateTime date, String title, String description){
        this.user = user;
        this.date = date;
        this.title = title;
        this.state = "aceptado";
        this.description = description;
    }

    public Post(User user, LocalDateTime date, String title, String description, String state){
        this(user, date, title, description);
        this.state = state;
    }

    public Long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public LocalDateTime getDate() { return date; }

    public String getTitle() { return title; }

    public String getDescription() { return description; }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setDate(LocalDateTime date) { this.date = date; }

    public void setTitle(String title) { this.title = title; }

    public void setDescription(String description) { this.description = description; }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Post{" +
                "id=" + id +
                ", date=" + date +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", state='" + state + '\'' +
                ", user=" + user +
                '}';
    }
}
