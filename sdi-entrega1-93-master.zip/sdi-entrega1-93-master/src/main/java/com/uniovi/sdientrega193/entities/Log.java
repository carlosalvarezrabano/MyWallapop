package com.uniovi.sdientrega193.entities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
public class Log {

    @Id
    @GeneratedValue
    private long id;

    private String type;
    private Timestamp date;
    private String description;

    public final static Logger logger = LoggerFactory.getLogger(Log.class);


    public Log(String type, Timestamp date, String description) {
        this.type = type;
        this.date = date;
        this.description = description;
    }

    public Log() {}

    @Override
    public String toString() {
        return "Logger{" +
                "type='" + type + '\'' +
                ", date=" + date +
                ", description='" + description + '\'' +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
