package com.uniovi.sdientrega193.repositories;

import com.uniovi.sdientrega193.entities.Friendship;
import com.uniovi.sdientrega193.entities.Post;
import com.uniovi.sdientrega193.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.format.annotation.DateTimeFormat;

import javax.transaction.Transactional;

public interface PostsRepository extends CrudRepository<Post, Long> {

    @Query("SELECT p from Post p where p.user = ?1 AND p.state in ('aceptado','moderado')")
    public Page<Post> findAllMyPosts(Pageable pageable, User user);

    public Page<Post> findAll(Pageable pageable);

    @Modifying
    @Transactional
    @Query("DELETE FROM Post p where p.user.id=?1")
    void removeByUser(long id);

    @Modifying
    @Transactional
    @Query("UPDATE Post p SET p.state = ?1 WHERE p.id = ?2")
    void setState(String state, long id);

    @Query("SELECT p from Post p where (lower(p.user.email) like lower(?1) or lower(p.title) like lower (?1)" +
            "or lower(p.state) like lower(?1))")
    Page<Post> findPostsByQueryText(Pageable pageable, String query);

    @Query("SELECT p from Post p where p.user = ?1 AND p.state = 'aceptado'")
    Page<Post> findAllMyPostsForFriends(Pageable pageable, User user);
}
