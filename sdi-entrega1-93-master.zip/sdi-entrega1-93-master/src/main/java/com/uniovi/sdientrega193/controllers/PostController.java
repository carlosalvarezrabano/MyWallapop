package com.uniovi.sdientrega193.controllers;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.entities.Post;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.services.LoggerService;
import com.uniovi.sdientrega193.services.PostService;
import com.uniovi.sdientrega193.services.UsersService;
import com.uniovi.sdientrega193.validators.AddPostFormValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Controller
public class PostController {

    @Autowired
    private PostService postService;
    @Autowired
    private UsersService usersService;
    @Autowired
    private AddPostFormValidator validator;

    @Autowired
    private LoggerService loggerService;


    /**
     * Controlador get para añadir una publicación
     * @param model
     * @param principal
     * @return la vista post/add
     */
    @RequestMapping(value = "/post/add")
    public String getPost(Model model, Principal principal) {
        model.addAttribute("activeUser", principal.getName());
        model.addAttribute("post", new Post());
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Añadir publicación");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/add"));
        return "post/add";
    }

    /**
     * Controlador post para añadir una publicación
     * @param post
     * @param principal
     * @param model
     * @param result
     * @return la vista post/list
     */
    @RequestMapping(value = "/post/add", method = RequestMethod.POST)
    public String setPost(@Validated Post post, Principal principal, Model model, BindingResult result) {
        validator.validate(post, result);
        if(result.hasErrors()) {
            model.addAttribute("activeUser", principal.getName());
            return "post/add";
        }
        User u = usersService.getUserByEmail(principal.getName());
        postService.addPost(post, u);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Añadir publicación (post)");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método POST con mapping /post/add"));
        return "redirect:/post/list";
    }

    /**
     * Controlador para listar las publicaciones
     * @param model
     * @param principal
     * @param pageable
     * @return la vista posy/list
     */
    @RequestMapping("/post/list")
    public String getListado(Model model, Principal principal, Pageable pageable) {
        Page<Post> myPosts = postService.getMyPosts(pageable, usersService.getUserByEmail(principal.getName()));
        model.addAttribute("page", myPosts);
        model.addAttribute("myPostsList", myPosts.getContent());
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Listar publicaciones");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/list"));
        return "post/list";
    }

    /**
     * Controlador para listar las publicaciones como admin
     * @param model
     * @param pageable
     * @return la vista /post/adminList
     */
    @RequestMapping("/post/adminList")
    public String getAdminList(Model model, Pageable pageable){
        Page<Post> posts = postService.getAllPosts(pageable);
        model.addAttribute("page", posts);
        model.addAttribute("postsList", posts.getContent());
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Listar publicaciones como admin");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/adminlist"));
        return "post/adminList";
    }

    /**
     * Controlador para buscar en la lista de publicaciones como admin
     * @param model
     * @param pageable
     * @param query
     * @return la vista post/adminList
     */
    @RequestMapping("/post/adminList/search")
    public String getAdminList(Model model, Pageable pageable, @RequestParam String query){

        Page<Post> posts = postService.getPostsByQuery(pageable,query);

        model.addAttribute("page", posts);
        model.addAttribute("postsList", posts.getContent());
        model.addAttribute("query", query);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Filtrar publicaciones como admin");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/adminlist"));
        return "post/adminList";
    }


    /**
     * Controlador para cambiar el estado de una publicación a aceptado pasando la id por url
     * @param id
     * @return la vista /post/adminList
     */
    @RequestMapping(value = "/post/aceptado/{id}", method = RequestMethod.GET)
    public String setAceptado( @PathVariable Long id) {
        if(!usersService.checkIfAdmin())
            return "redirect:/logout";
        postService.setState("aceptado", id);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Método get de aceptar");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/aceptado/{id} con parametro id del post"));
        return "redirect:/post/adminList";
    }


    /**
     * Controlador para cambiar el estado de una publicación a moderado pasando la id por url
     * @param id
     * @return la vista /post/adminList
     */
    @RequestMapping(value = "/post/moderado/{id}", method = RequestMethod.GET)
    public String setModerado( @PathVariable Long id) {
        if(!usersService.checkIfAdmin())
            return "redirect:/logout";
        postService.setState("moderado", id);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Método get de moderar");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/moderado/{id} con parametro id del post"));
        return "redirect:/post/adminList";
    }


    /**
     * Controlador para cambiar el estado de una publicación a censurado pasando la id por url
     * @param id
     * @return la vista /post/adminList
     */
    @RequestMapping(value = "/post/censurado/{id}", method = RequestMethod.GET)
    public String setCensurado( @PathVariable Long id) {
        if(!usersService.checkIfAdmin())
            return "redirect:/logout";
        postService.setState("censurado", id);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Método get de censurar");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /post/censurado/{id} con parametro id del post"));
        return "redirect:/post/adminList";
    }


}
