package com.uniovi.sdientrega193.controllers;

import com.uniovi.sdientrega193.entities.Log;
import com.uniovi.sdientrega193.entities.FriendRequest;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import java.sql.Timestamp;
import java.security.Principal;


@Controller
public class FriendRequestController {

    @Autowired
    private FriendRequestService friendRequestService;

    @Autowired
    private UsersService usersService;

    @Autowired
    private LoggerService loggerService;


    /**
     * Controlador para añadir usuario
     * @param id_recoge
     * @return vista de user/list
     */
    @RequestMapping(value = "/friendRequest/add/{id_recoge}", method = RequestMethod.GET)
    public String addFriendRequest(@PathVariable Long id_recoge){
        if (!friendRequestService.alreadyFriends(id_recoge)) {
            friendRequestService.addFriendRequest(id_recoge);
            Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Mandar soliticud de amistad");
            loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                    "Método GET con mapping /friendRequest/add/{id_recoge} y parámetro id de la persona a enviar la peticion"));
        }
        return "redirect:/user/list";
    }


    /**
     * Controlador de listar las peticiones de amistad
     * @param model
     * @param pageable
     * @param principal
     * @return vista de friendRequest/list
     */
    @RequestMapping("/friendRequest/list")
    public String getList(Model model, Pageable pageable, Principal principal){
        String email = principal.getName();
        User user = usersService.getUserByEmail(email);
        Page<FriendRequest> requests;
        requests = friendRequestService.getRequestsForUser(pageable, user);

        model.addAttribute("requestList", requests.getContent());
        model.addAttribute("page", requests);

        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Listar solicitudes de amistad");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /friendRequest/list"));

        return "friendRequest/list";
    }

    /**
     * Controlador para aceptar la petición de amistad pasando el id por url
     * @param id
     * @return la vista friendRequesr/list
     */
    @RequestMapping("/friendRequest/accept/{id}")
    public String accept(@PathVariable Long id){
        friendRequestService.accept(id);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Aceptar una solicitud de amistad");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /friendRequest/accept/{id} y parámetro id de la persona a aceptar la peticion"));
        return "redirect:/friendRequest/list";
    }


    /**
     * Controlador para rechazar la petición de amistad pasando el id por url
     * @param id
     * @return la vista friendRequest/list
     */
    @RequestMapping("/friendRequest/reject/{id}")
    public String reject(@PathVariable Long id){
        friendRequestService.reject(id);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Rechazar una solicitud de amistad");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /friendRequest/accept/{id} y parámetro id de la persona a rechazar la peticion"));
        return "redirect:/friendRequest/list";
    }


    /**
     * Controlador para actualizar el fragmento de la lista de las peticiones de amistad
     * @param model
     * @param pageable
     * @param principal
     * @return el fragmento de la tabla de peticiones fragments/tableRequests/
     */
    @RequestMapping("/friendRequest/list/update")
    public String updateList(Model model, Pageable pageable, Principal principal) {
        String email = principal.getName(); // email es el name de la autenticación
        User user = usersService.getUserByEmail(email);
        Page<FriendRequest> requests= friendRequestService.getRequestsForUser(pageable, user);
        model.addAttribute("requestList", requests.getContent());
        model.addAttribute("page", requests);
        Log.logger.debug(new Timestamp(System.currentTimeMillis())+"--> Actualizar la lista de solicitudes de amistad");
        loggerService.addLog(new Log("PET", new Timestamp(System.currentTimeMillis()),
                "Método GET con mapping /friendRequest/list/update para actualizar la lista de solicitudes"));
        return "fragments/tableRequests :: table";
    }

}
