package com.uniovi.sdientrega193.services;

import com.uniovi.sdientrega193.entities.FriendRequest;
import com.uniovi.sdientrega193.entities.Friendship;
import com.uniovi.sdientrega193.entities.Post;
import com.uniovi.sdientrega193.entities.User;
import com.uniovi.sdientrega193.repositories.FriendRequestsRepository;
import com.uniovi.sdientrega193.repositories.FriendshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Set;

@Service
public class InsertSampleDataService {
    @Autowired
    private UsersService usersService;
    @Autowired
    private RolesService rolesService;
    @Autowired
    private FriendshipRepository friendshipRepo;
    @Autowired
    private FriendRequestService friendRequestService;
    @Autowired
    private FriendRequestsRepository friendRequestsRepository;

    /**
     * añade datos de ejemplo para pruebas
     */
    @PostConstruct
    public void init() {
        User user1 = new User("user01@email.com", "user01", "user01");
        user1.setPassword("user01");
        user1.setRole(rolesService.getRoles()[0]);
        User user2 = new User("user02@email.com", "user02", "user02");
        user2.setPassword("user02");
        user2.setRole(rolesService.getRoles()[0]);
        User user3 = new User("user03@email.com", "user03", "user03");
        user3.setPassword("user03");
        user3.setRole(rolesService.getRoles()[0]);
        User user4 = new User("user04@email.com", "user04", "user04");
        user4.setPassword("user04");
        user4.setRole(rolesService.getRoles()[0]);
        User user5 = new User("user05@email.com", "user05", "user05");
        user5.setPassword("user05");
        user5.setRole(rolesService.getRoles()[0]);
        User user6 = new User("user06@email.com", "user06", "user06");
        user6.setPassword("user06");
        user6.setRole(rolesService.getRoles()[0]);
        User user7 = new User("user07@email.com", "user07", "user07");
        user7.setPassword("user07");
        user7.setRole(rolesService.getRoles()[0]);
        User user8 = new User("user08@email.com", "user08", "user08");
        user8.setPassword("user08");
        user8.setRole(rolesService.getRoles()[0]);
        User user9 = new User("user09@email.com", "user09", "user09");
        user9.setPassword("user09");
        user9.setRole(rolesService.getRoles()[0]);
        User user10 = new User("user10@email.com", "user10", "user10");
        user10.setPassword("user10");
        user10.setRole(rolesService.getRoles()[0]);
        User user11 = new User("user11@email.com", "user11", "user11");
        user11.setPassword("user11");
        user11.setRole(rolesService.getRoles()[0]);
        User user12 = new User("user12@email.com", "user12", "user12");
        user12.setPassword("user12");
        user12.setRole(rolesService.getRoles()[0]);
        User user13 = new User("user13@email.com", "user13", "user13");
        user13.setPassword("user13");
        user13.setRole(rolesService.getRoles()[0]);
        User user14 = new User("user14@email.com", "user14", "user14");
        user14.setPassword("user14");
        user14.setRole(rolesService.getRoles()[0]);
        User user15 = new User("user15@email.com", "user15", "user15");
        user15.setPassword("user15");
        user15.setRole(rolesService.getRoles()[0]);
        User user16 = new User("user16@email.com", "user16", "user16");
        user16.setPassword("user16");
        user16.setRole(rolesService.getRoles()[0]);
        User user17 = new User("user17@email.com", "user17", "user17");
        user17.setPassword("user17");
        user17.setRole(rolesService.getRoles()[0]);
        User user18 = new User("user18@email.com", "user18", "user18");
        user18.setPassword("user18");
        user18.setRole(rolesService.getRoles()[0]);
        User user19 = new User("user19@email.com", "user19", "user19");
        user19.setPassword("user19");
        user19.setRole(rolesService.getRoles()[0]);
        User user20 = new User("user20@email.com", "user20", "user20");
        user20.setPassword("user20");
        user20.setRole(rolesService.getRoles()[0]);
        User admin = new User("admin@email.com", "admin", "admin");
        admin.setPassword("admin");
        admin.setRole(rolesService.getRoles()[1]);

        Set user1Posts = new HashSet<Post>() {
            {
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user1, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user2Posts = new HashSet<Post>() {
            {
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user2, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user3Posts = new HashSet<Post>() {
            {
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user3, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user4Posts = new HashSet<Post>() {
            {
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user4, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user5Posts = new HashSet<Post>() {
            {
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user5, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user6Posts = new HashSet<Post>() {
            {
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user6, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user7Posts = new HashSet<Post>() {
            {
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user7, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user8Posts = new HashSet<Post>() {
            {
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user8, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user9Posts = new HashSet<Post>() {
            {
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user9, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user10Posts = new HashSet<Post>() {
            {
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user10, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user11Posts = new HashSet<Post>() {
            {
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user11, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user12Posts = new HashSet<Post>() {
            {
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user12, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user13Posts = new HashSet<Post>() {
            {
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user13, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user14Posts = new HashSet<Post>() {
            {
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 11", "My eleventh post", "censurado"));
                add(new Post(user14, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 12", "My twelveth post", "moderado"));
            }
        };
        Set user15Posts = new HashSet<Post>() {
            {
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user15, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user16Posts = new HashSet<Post>() {
            {
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user16, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user17Posts = new HashSet<Post>() {
            {
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user17, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user18Posts = new HashSet<Post>() {
            {
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user18, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user19Posts = new HashSet<Post>() {
            {
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user19, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };
        Set user20Posts = new HashSet<Post>() {
            {
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 1", "My first post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 2", "My second post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 3", "My third post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 4", "My fourth post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 5", "My fiveth post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 6", "My sixth post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 7", "My seventh post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 8", "My eighth post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 9", "My nineth post"));
                add(new Post(user20, LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES), "Post 10", "My tenth post"));
            }
        };

        user1.setPosts(user1Posts);
        user2.setPosts(user2Posts);
        user3.setPosts(user3Posts);
        user4.setPosts(user4Posts);
        user5.setPosts(user5Posts);
        user6.setPosts(user6Posts);
        user7.setPosts(user7Posts);
        user8.setPosts(user8Posts);
        user9.setPosts(user9Posts);
        user10.setPosts(user10Posts);
        user11.setPosts(user11Posts);
        user12.setPosts(user12Posts);
        user13.setPosts(user13Posts);
        user14.setPosts(user14Posts);
        user15.setPosts(user15Posts);
        user16.setPosts(user16Posts);
        user17.setPosts(user17Posts);
        user18.setPosts(user18Posts);
        user19.setPosts(user19Posts);
        user20.setPosts(user20Posts);

        usersService.addUser(user1);
        usersService.addUser(user2);
        usersService.addUser(user3);
        usersService.addUser(user4);
        usersService.addUser(user5);
        usersService.addUser(admin);
        usersService.addUser(user6);
        usersService.addUser(user7);
        usersService.addUser(user8);
        usersService.addUser(user9);
        usersService.addUser(user10);
        usersService.addUser(user11);
        usersService.addUser(user12);
        usersService.addUser(user13);
        usersService.addUser(user14);
        usersService.addUser(user15);
        usersService.addUser(user16);
        usersService.addUser(user17);
        usersService.addUser(user18);
        usersService.addUser(user19);
        usersService.addUser(user20);

        friendshipRepo.save(new Friendship(user1,user2));
        friendshipRepo.save(new Friendship(user1,user3));
        friendshipRepo.save(new Friendship(user4, user1));
        friendshipRepo.save(new Friendship(user14,user13));
        friendshipRepo.save(new Friendship(user14,user12));
        friendshipRepo.save(new Friendship(user14,user2));

        FriendRequest fr1 = new FriendRequest(user2, user3);
        friendRequestsRepository.save(fr1);
        FriendRequest fr2 = new FriendRequest(user10, user2);
        friendRequestsRepository.save(fr2);
        FriendRequest fr3 = new FriendRequest(user11, user2);
        friendRequestsRepository.save(fr3);
        FriendRequest fr4 = new FriendRequest(user2, user11);
        friendRequestsRepository.save(fr4);
        FriendRequest fr5 = new FriendRequest(user12, user2);
        friendRequestsRepository.save(fr5);
    }
}
