package com.uniovi.sdientrega193.validators;

import com.uniovi.sdientrega193.entities.Post;
import com.uniovi.sdientrega193.services.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class AddPostFormValidator implements Validator {

    @Autowired
    private PostService postService;

    @Override
    public boolean supports(Class<?> clazz) {
        return Post.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Post post = (Post) target;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "Error.addpost.title.empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "Error.addpost.description.empty");
    }
}
