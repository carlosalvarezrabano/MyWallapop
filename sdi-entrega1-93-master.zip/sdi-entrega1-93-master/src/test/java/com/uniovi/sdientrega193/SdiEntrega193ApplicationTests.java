package com.uniovi.sdientrega193;

import com.uniovi.sdientrega193.pageobjects.*;
import com.uniovi.sdientrega193.util.SeleniumUtils;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SdiEntrega193ApplicationTests {


    //static String Geckodriver = "C:\\Users\\juann\\Desktop\\uniovi.es\\SDI\\practicas\\trabajo en grupo\\geckodriver-v0.30.0-win64.exe";
    //static String Geckodriver = "C:\\Users\\natal\\Downloads\\PL-SDI-Sesión5-material\\PL-SDI-Sesión5-material\\geckodriver-v0.30.0-win64.exe";
    static String Geckodriver = "C:\\Users\\juann\\Desktop\\uniovi.es\\SDI\\practicas\\trabajo en grupo\\geckodriver-v0.30.0-win64.exe";
    //static String Geckodriver = "C:\\Users\\natal\\Downloads\\PL-SDI-Sesión5-material\\PL-SDI-Sesión5-material\\geckodriver-v0.30.0-win64.exe";
    //static String Geckodriver = "D:\\Users\\Alonso\\Desktop\\Clase\\Uni\\4o Curso - 2021-22\\2o Cuatri\\SDI\\Lab\\Lab05\\PL-SDI-Sesión5-material\\geckodriver-v0.30.0-win64.exe";

    static String PathFirefox = "C:\\Program Files\\Mozilla Firefox\\firefox.exe";
    static WebDriver driver = getDriver(PathFirefox, Geckodriver);
    static String URL = "http://localhost:8090/";
    public static WebDriver getDriver(String PathFirefox, String Geckodriver) {
        System.setProperty("webdriver.firefox.bin", PathFirefox);
        System.setProperty("webdriver.gecko.driver", Geckodriver);
        driver = new FirefoxDriver();
        return driver;
    }

    @BeforeEach
    public void setUp(){
        driver.navigate().to(URL);
    }

    //Después de cada prueba se borran las cookies del navegador
    @AfterEach
    public void tearDown(){
        driver.manage().deleteAllCookies();
    }

    //Antes de la primera prueba
    @BeforeAll
    static public void begin() {}

    //Al finalizar la última prueba
    @AfterAll
    static public void end() {
        //Cerramos el navegador al finalizar las pruebas
        driver.quit();
    }

    // PRUEBAS DEL PUNTO 1

    //PR01. Prueba del formulario de registro. registro con datos correctos
    @Test
    @Order(1)
    public void PR01() {
        //Vamos al formulario de registro
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        //Rellenamos el formulario.
        String email = "opaco@uniovi.es";
        PO_SignUpView.fillForm(driver, email, "paco", "Perez", "77777", "77777");
        //Comprobamos que entramos en la sección privada y nos muestra el texto a buscar
        String checkText = "Esta es una zona privada la web";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR02. Prueba del formulario de registro. registro con email, nombre y apellidos vacios
    @Test
    @Order(2)
    public void PR02() {
        //Vamos al formulario de registro
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        //Rellenamos el formulario.
        String email = "";
        PO_SignUpView.fillForm(driver, email, "", "", "77777", "77777");
        List<WebElement> result = PO_SignUpView.checkElementByKey(driver, "Error.signup.email.empty",
                PO_Properties.getSPANISH() );
        //Comprobamos el error de email vacio.
        String checkText = PO_HomeView.getP().getString("Error.signup.email.empty",
                PO_Properties.getSPANISH());
        Assertions.assertEquals(checkText , result.get(0).getText());

        result = PO_SignUpView.checkElementByKey(driver, "Error.signup.name.empty",
                PO_Properties.getSPANISH() );
        //Comprobamos el error de nombre vacio.
        checkText = PO_HomeView.getP().getString("Error.signup.name.empty",
                PO_Properties.getSPANISH());
        Assertions.assertEquals(checkText , result.get(0).getText());

        result = PO_SignUpView.checkElementByKey(driver, "Error.signup.lastname.empty",
                PO_Properties.getSPANISH() );
        //Comprobamos el error de apellido vacio.
        checkText = PO_HomeView.getP().getString("Error.signup.lastname.empty",
                PO_Properties.getSPANISH());
        Assertions.assertEquals(checkText , result.get(0).getText());
    }

    //PR03. Prueba del formulario de registro. contraseñas no coincidentes.
    // Propiedad: Error.signup.passwordConfirm.coincidence
    @Test
    @Order(3)
    public void PR03() {
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        PO_SignUpView.fillForm(driver, "xml@gmail.com", "JosePerez", "Perez", "666666", "77777");
        List<WebElement> result = PO_SignUpView.checkElementByKey(driver, "Error.signup.passwordConfirm.coincidence",
                PO_Properties.getSPANISH() );
        //Comprobamos el error de contraseñas no coincidentes.
        String checkText = PO_HomeView.getP().getString("Error.signup.passwordConfirm.coincidence",
                PO_Properties.getSPANISH());
        Assertions.assertEquals(checkText , result.get(0).getText());
    }

    //PR03. Prueba del formulario de registro. Email repetido en la BD
    // Propiedad: Error.signup.email.duplicate
    @Test
    @Order(4)
    public void PR04() {
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        PO_SignUpView.fillForm(driver, "user01@email.com", "user01", "user01", "user01", "user01");
        List<WebElement> result = PO_SignUpView.checkElementByKey(driver, "Error.signup.email.duplicate",
                PO_Properties.getSPANISH() );
        //Comprobamos el error de DNI repetido.
        String checkText = PO_HomeView.getP().getString("Error.signup.email.duplicate",
                PO_Properties.getSPANISH());
        Assertions.assertEquals(checkText , result.get(0).getText());
    }

    // PRUEBAS DEL PUNTO 2

    //PR05. Prueba de inicio de sesion con datos validos. administrador
    @Test
    @Order(5)
    public void PR05() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        //Comprobamos que entramos en la pagina privada de Alumno
        String checkText = "Los usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR06. Prueba de inicio de sesion con datos validos. usuario estandar
    @Test
    @Order(6)
    public void PR06() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada de Alumno
        String checkText = "Los usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR07. Prueba de inicio de sesion con datos invalidos. email y contraseña vacios
    @Test
    @Order(7)
    public void PR07() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "", "");
        //Comprobamos que entramos en la pagina privada de Alumno
        String checkText = "Identifícate";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR08. Prueba de inicio de sesion con datos invalidos. email existente y contraseña invalida
    @Test
    @Order(8)
    public void PR08() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "juan@uniovi.es", "aaa");
        //Comprobamos que entramos en la pagina privada de Alumno
        String checkText = "Identifícate";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    // PRUEBAS DEL PUNTO 3

    //PR09. Hacer clic en el boton de salir de sesion y comprobar que estamos en la pagina del login
    @Test
    @Order(9)
    public void PR09() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        WebElement logout = driver.findElement(By.xpath("//*[@id=\"navbarScroll\"]/ul/li[5]/a"));
        logout.click();
        //Comprobamos que nos conectamos, nos desconectamos y estamos de nuevo en la pagina de login
        String checkText = "Identifícate";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR10. comprobar que el boton de logout no esta disponible si el usuario no esta autenticado
    @Test
    @Order(10)
    public void PR10() {
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Cerrar sesión",PO_View.getTimeout());
    }

    // PRUEBAS DEL PUNTO 4

    //PR11. mostrar el listado de usuarios y comprobar que salen todos los del sistema
    @Test
    @Order(11)
    public void PR11() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'user/list')]");
        elements.get(0).click();
        // seleccionamos las filas de la tabla
        elements = PO_View.checkElementBy(driver, "free", "//*[@class=\"user\"]");
        int users = elements.size();
        Assertions.assertEquals(22, users);
    }

    // PRUEBAS DEL PUNTO 5


    //PR12. borrar el primer usuario de la lista de usuarios
    @Test
    @Order(12)
    public void PR12() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'user/list')]");
        elements.get(0).click();
        // seleccionamos el primer usuario
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[@id=\"1\"]").get(0);
        element.click();
        // borramos el primer usuario
        element = PO_View.checkElementBy(driver, "free", "//*[@id=\"deletebutton\"]").get(0);
        element.click();
        // comprobamos que no aparece el primer usuario
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user01@email.com",PO_View.getTimeout());
    }

    //PR13. borrar el último usuario de la lista de usuarios
    @Test
    @Order(13)
    public void PR13() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'user/list')]");
        elements.get(0).click();
        // seleccionamos los usuarios disponibles
        elements = PO_View.checkElementBy(driver, "free", "//*[@class=\"user\"]");
        // seleccionamos el ultimo usuario
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[@id=\"213\"]").get(0);
        element.click();
        // borramos el último usuario
        element = PO_View.checkElementBy(driver, "free", "//*[@id=\"deletebutton\"]").get(0);
        element.click();
        // comprobamos que no aparece el usuario
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "homer@uniovi.es",PO_View.getTimeout());
    }

    //PR14. borrar 3 usuarios y comprobar que la lista se actualiza
    @Test
    @Order(14)
    public void PR14() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'user/list')]");
        elements.get(0).click();
        // seleccionamos 3 usuarios
        elements = PO_View.checkElementBy(driver, "free", "//input[@class=\"form-check-input\"]");
        WebElement element = elements.get(elements.size()-1);
        element.click();
        element = elements.get(elements.size()-2);
        element.click();
        element = elements.get(elements.size()-3);
        element.click();
        // borramos
        element = PO_View.checkElementBy(driver, "free", "//*[@id=\"deletebutton\"]").get(0);
        element.click();
        // comprobamos que no aparecen
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user20@email.com",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user19@email.com",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user18@email.com",PO_View.getTimeout());
    }

    // PRUEBAS DEL PUNTO 6

    //PR15. mostrar el listado de usuarios y comprobar que salen todos los del sistema menos el propio usuario
    // y el administrador
    @Test
    @Order(15)
    public void PR15() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user07@email.com", "user07");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'user/list')]");
        elements.get(0).click();
        // seleccionamos las paginas disponibles
        List<WebElement> paginas = PO_View.checkElementBy(driver, "free", "/html/body/div/div/div/ul");
        // recorremos las paginas contando los usuarios y mirando que no esten ni el admin ni el propio usuario
        int numUsers = 0;
        List<WebElement> usuarios;
        for(int i = 0; i < paginas.size(); i++){
            paginas.get(i).click();
            usuarios = PO_View.checkElementBy(driver, "free", "//*[@id=\"table\"]/tbody/tr");
            numUsers += usuarios.size();
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user07@email.com",PO_View.getTimeout());
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "admin@email.com",PO_View.getTimeout());
        }
        Assertions.assertEquals(5, numUsers);
    }

    //PRUEBAS DEL PUNTO 7

    //PR16. Hacer una búsqueda con el campo vacío y comprobar que se muestra la página que
    //corresponde con el listado usuarios existentes en el sistema
    @Test
    @Order(16)
    public void PR16() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        //Presionamos el boton de buscar y comprobamos que sale la lista completa de usuarios
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();
        List<WebElement> userList = SeleniumUtils.waitLoadElementsBy(driver, "free", "//tbody/tr",
                PO_View.getTimeout());
        Assertions.assertEquals(5, userList.size());
    }

    //PR17. Hacer una búsqueda escribiendo en el campo un texto que no exista y comprobar que se
    //muestra la página que corresponde, con la lista de usuarios vacía
    @Test
    @Order(17)
    public void PR17() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        //Nos situamos en el buscador de usuarios y lo dejamos en blanco
        WebElement searchText = driver.findElement(By.name("searchText"));
        searchText.click();
        searchText.clear();
        searchText.sendKeys("noexiste");
        //Presionamos el boton de buscar y comprobamos que sale la lista vacia
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();
        SeleniumUtils.waitSeconds(driver, 15);
        String text = PO_View.getP().getString("tableUsers.nousers", PO_Properties.getSPANISH());
        SeleniumUtils.textIsPresentOnPage(driver, text);
    }

    //PR18. Hacer una búsqueda con un texto específico y comprobar que se muestra la página que
    //corresponde, con la lista de usuarios en los que el texto especificado sea parte de su nombre, apellidos o
    //de su email
    @Test
    @Order(18)
    public void PR18() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        SeleniumUtils.waitSeconds(driver, 5);
        //Nos situamos en el buscador de usuarios y buscamos un usuario
        WebElement searchText = driver.findElement(By.name("searchText"));
        searchText.click();
        searchText.clear();
        searchText.sendKeys("user12");
        //Presionamos el boton de buscar y comprobamos que sale dicho usuario
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();
        SeleniumUtils.waitSeconds(driver, 15);
        List<WebElement> userList = SeleniumUtils.waitLoadElementsBy(driver, "free", "//tbody/tr",
                PO_View.getTimeout());
        Assertions.assertEquals(1, userList.size());
        SeleniumUtils.textIsPresentOnPage(driver, "user12@email.com");
    }

    // PRUEBAS DEL PUNTO 8

    //PR19 Desde el listado de usuarios de la aplicación, enviar una invitación de amistad a un usuario.
    @Test
    @Order(19)
    public void PR19() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user03@email.com", "user03");
        SeleniumUtils.waitSeconds(driver, 5);

        SeleniumUtils.textIsPresentOnPage(driver, "user02@email.com");
        List<WebElement> result = PO_View.checkElementBy(driver, "text", "Agregar amigo");
        Assertions.assertEquals("Agregar amigo",result.get(0).getText());

        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequest/add')]");
        elements.get(0).click();
        SeleniumUtils.waitSeconds(driver, 5);
        SeleniumUtils.textIsPresentOnPage(driver, "Solicitud enviada");

        //comprobar que sale en el listado en el user02
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "logout", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        SeleniumUtils.waitSeconds(driver, 5);

        WebElement option = driver.findElement(By.xpath("//*[@id=\"friendRequests_link\"]"));
        option.click();
        elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequest/list')]");
        elements.get(0).click();
        SeleniumUtils.waitSeconds(driver, 5);
        SeleniumUtils.textIsPresentOnPage(driver, "user03");
        //PO_HomeView.clickOption(driver, "post/list", "class", "btn btn-primary");
    }

    //PR20 Desde el listado de usuarios de la aplicación, enviar una invitación de amistad a un usuario al
    //que ya le habíamos enviado la invitación previamente

    @Test
    @Order(20)
    public void PR20() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user03@email.com", "user03");
        SeleniumUtils.waitSeconds(driver, 5);

        SeleniumUtils.textIsPresentOnPage(driver, "user02@email.com");
        List<WebElement> result = PO_View.checkElementBy(driver, "text", "Agregar amigo");
        Assertions.assertEquals("Agregar amigo",result.get(0).getText());

        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequest/add')]");
        elements.get(0).click();
        SeleniumUtils.waitSeconds(driver, 5);
        SeleniumUtils.textIsPresentOnPage(driver, "Solicitud enviada");
    }

    // PRUEBAS DEL PUNTO 9

    //PR21. Mostrar el listado de invitaciones de amistad recibidas. Comprobar con un listado que
    //contenga varias invitaciones recibidas
    @Test
    @Order(21)
    public void PR21() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        WebElement option = driver.findElement(By.xpath("//a[@id=\"friendRequests_link\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequest/list')]");
        elements.get(0).click();
        // seleccionamos las filas de la tabla
        elements = PO_View.checkElementBy(driver, "free", "//*[@class=\"request\"]");
        int requests = elements.size();
        Assertions.assertNotEquals(0, requests);
    }

    // PRUEBAS DEL PUNTO 10
    //PR22. Sobre el listado de invitaciones recibidas. Hacer clic en el botón/enlace de una de ellas y
    //comprobar que dicha solicitud desaparece del listado de invitaciones.
    @Test
    @Order(22)
    public void PR22() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"friendRequests_link\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequest/list')]");
        elements.get(0).click();
        // seleccionamos las filas de la tabla
        elements = PO_View.checkElementBy(driver, "free", "//*[@class=\"btn btn-outline-primary\"]");
        elements.get(0).click();
        // comprobamos que esa solicitud desaparece
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user10",PO_View.getTimeout());
    }

    // PRUEBAS DEL PUNTO 11

    //PR23. mostrar el listado de amistades y comprobar que son las que deberian ser
    @Test
    @Order(23)
    public void PR23() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//*[@id=\"navbarScroll\"]/ul/li[2]/ul/li[2]/a");
        elements.get(0).click();
        // seleccionamos las paginas disponibles
        List<WebElement> paginas = PO_View.checkElementBy(driver, "free", "/html/body/div/div/div/ul");
        // recorremos las paginas contando los usuarios y mirando que no esten ni el admin ni el propio usuario
        int numUsers = 0;
        List<WebElement> usuarios;
        for(int i = 0; i < paginas.size(); i++){
            paginas.get(i).click();
            usuarios = PO_View.checkElementBy(driver, "free", "//*[@class=\"friend\"]");
            numUsers += usuarios.size();
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user14@email.com",PO_View.getTimeout());
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "admin@email.com",PO_View.getTimeout());
        }
        Assertions.assertEquals(3, numUsers);
    }

    //PRUEBAS DEL CASO 12

    //PR24. Ir al formulario crear publicaciones, rellenarla con datos válidos y pulsar el botón Submit.
    //Comprobar que la publicación sale en el listado de publicaciones de dicho usuario
    @Test
    @Order(24)
    public void PR24() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user03@email.com", "user03");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'post/add')]");
        elements.get(0).click();
        //Rellenamos los datos del formulario de añadir publicacion
        WebElement title = driver.findElement(By.id("title"));
        title.click();
        title.clear();
        title.sendKeys("Post de prueba");
        WebElement description = driver.findElement(By.id("description"));
        description.click();
        description.clear();
        description.sendKeys("Post de prueba");
        //Le damos al boton de enviar y comprobamos que la publicacion se ha añadido correctamente
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();
        SeleniumUtils.waitSeconds(driver, 15);
        List<WebElement> postList = SeleniumUtils.waitLoadElementsBy(driver, "free", "//tbody/tr",
                PO_View.getTimeout());
        Assertions.assertEquals(5, postList.size());
    }

    //PR25. Ir al formulario de crear publicaciones, rellenarla con datos inválidos (campo título vacío) y
    //pulsar el botón Submit. Comprobar que se muestra el mensaje de campo obligatorio
    @Test
    @Order(25)
    public void PR25() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user03@email.com", "user03");
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'post/add')]");
        elements.get(0).click();
        //Rellenamos los datos del formulario de añadir publicacion
        WebElement description = driver.findElement(By.id("description"));
        description.click();
        description.clear();
        description.sendKeys("Post de prueba");
        //Le damos al boton de enviar y comprobamos que la publicacion se ha añadido correctamente
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();
        SeleniumUtils.waitSeconds(driver, 15);
        String text = PO_View.getP().getString("addpost.head", PO_Properties.getSPANISH());
        SeleniumUtils.textIsPresentOnPage(driver, text);
    }

    //PRUEBAS DEL CASO 13

    //PR26. Mostrar el listado de publicaciones de un usuario y comprobar que se muestran todas las que
    //existen para dicho usuario
    @Test
    @Order(26)
    public void PR26() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user03@email.com", "user03");
        SeleniumUtils.waitSeconds(driver, 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'post/list')]");
        elements.get(0).click();
        SeleniumUtils.waitSeconds(driver, 10);
        List<WebElement> postList = SeleniumUtils.waitLoadElementsBy(driver, "free", "//tbody/tr",
                PO_View.getTimeout());
        Assertions.assertEquals(5, postList.size());
    }

    //PRUEBAS DEL CASO 14
    //PR27. Mostrar el listado de publicaciones de un usuario amigo y comprobar que se muestran todas
    //las que existen para dicho usuario
    @Test
    @Order(27)
    public void PR27() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        SeleniumUtils.waitSeconds(driver, 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendship/list')]");
        elements.get(0).click();
        SeleniumUtils.waitSeconds(driver, 10);
        By enlace = By.xpath("//a[contains(@href, 'friendship/postslist/1')]");
        driver.findElement(enlace).click();
        SeleniumUtils.waitSeconds(driver, 10);
        //Presionamos el boton de ver publicaciones y comprobamos que sale la lista completa de publicaciones
        List<WebElement> postList = SeleniumUtils.waitLoadElementsBy(driver, "free", "//tbody/tr",
                PO_View.getTimeout());
        Assertions.assertEquals(5, postList.size());
    }

    //PR28. Utilizando un acceso vía URL u otra alternativa, tratar de listar las publicaciones de un usuario
    //que no sea amigo del usuario identificado en sesión. Comprobar que el sistema da un error de autorización
    @Test
    @Order(28)
    public void PR28() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user04@email.com", "user04");
        //accedemos directamente a un id de un usuario que no es amigo nuestro y comprobamos que nos redirige al
        //listado de amigos
        driver.navigate().to(URL+"friendship/postslist/2");
        List<WebElement> elements = PO_View.checkElementBy(driver, "text", "Usuarios");
        String text = PO_View.getP().getString("friendship.list.title", PO_Properties.getSPANISH());
        Assertions.assertEquals(text, elements.get(0).getText());
    }




    //PR29. Visualizar al menos cuatro páginas en español/inglés/español (comprobando que algunas de
    //las etiquetas cambian al idioma correspondiente). Ejemplo, Página principal/Opciones Principales de
    //Usuario/Listado de Usuarios.
    @Test
    @Order(29)
    public void PR29() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        //aqui estamos en el listado de usuarios
        //pinchamos ingles y comprobamos ingles
        WebElement option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnEnglish\"]"));
        option.click();
        List<WebElement> result = PO_View.checkElementBy(driver, "text", "Users");
        Assertions.assertEquals("Users",result.get(0).getText());
        //volvemos español
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnSpanish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "Usuarios");
        Assertions.assertEquals("Usuarios",result.get(0).getText());

        //pagina de listado de posts
        option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'post/list')]");
        elements.get(0).click();
        //pinchamos ingles y comprobamos ingles
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnEnglish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "My third post");
        Assertions.assertEquals("My third post",result.get(0).getText());
        //volvemos español
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnSpanish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "Tus publicaciones que actualmente figuran en el sistema son las siguientes");
        Assertions.assertEquals("Tus publicaciones que actualmente figuran en el sistema son las siguientes" ,result.get(0).getText());

        //pagina de añadir post
        option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'post/add')]");
        elements.get(0).click();
        //pinchamos ingles y comprobamos ingles
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnEnglish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "Description");
        Assertions.assertEquals("Description",result.get(0).getText());
        //volvemos español
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnSpanish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "Descripción");
        Assertions.assertEquals("Descripción",result.get(0).getText());

        //cerrar sesión
        //pinchamos ingles y comprobamos ingles
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnEnglish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "Log out");
        Assertions.assertEquals("Log out",result.get(0).getText());
        //volvemos español
        option = driver.findElement(By.xpath("//*[@id=\"btnLanguage\"]"));
        option.click();
        option = driver.findElement(By.xpath("//*[@id=\"btnSpanish\"]"));
        option.click();
        result = PO_View.checkElementBy(driver, "text", "Cerrar sesión");
        Assertions.assertEquals("Cerrar sesión",result.get(0).getText());
    }


    //CASOS DE PRUEBA PARA EL PUNTO 17  (1,20,19,18,17)

    //PR30. Intentar acceder sin estar autenticado a la opción de listado de usuarios. Se deberá volver al
    //formulario de login.
    @Test
    @Order(30)
    public void PR30() {
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"user/list");
        SeleniumUtils.textIsPresentOnPage(driver, "Identifícate");

    }


    //PR31. Intentar acceder sin estar autenticado a la opción de listado de invitaciones de amistad recibida
    //de un usuario estándar. Se deberá volver al formulario de login.
    @Test
    @Order(31)
    public void PR31() {
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"friendRequest/list");
        SeleniumUtils.textIsPresentOnPage(driver, "Identifícate");

    }



    //PR32. Estando autenticado como usuario estándar intentar acceder a una opción disponible solo
    //    para usuarios administradores (Añadir menú de auditoria (visualizar logs)). Se deberá indicar un mensaje
    //    de acción prohibida.    status=403
    @Test
    @Order(32)
    public void PR32() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"log/list");
        SeleniumUtils.textIsPresentOnPage(driver, "status=403");

    }

    //PR33. Estando autenticado como usuario administrador visualizar todos los logs generados en una
    //serie de interacciones. Esta prueba deberá generar al menos dos interacciones de cada tipo y comprobar
    //que el listado incluye los logs correspondientes.
    @Test
    @Order(33)
    public void PR33() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"post/list");

        WebElement logout = driver.findElement(By.xpath("//*[@id=\"navbarScroll\"]/ul/li[5]/a"));
        logout.click();

        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"log/list");
        SeleniumUtils.textIsPresentOnPage(driver, "PET");
        SeleniumUtils.textIsPresentOnPage(driver, "LOG-EX");
    }



    //PR33. Estando autenticado como usuario administrador, ir a visualización de logs, pulsar el
    //botón/enlace borrar logs y comprobar que se eliminan los logs de la base de datos.
    @Test
    @Order(34)
    public void PR34() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"post/list");

        WebElement logout = driver.findElement(By.xpath("//*[@id=\"navbarScroll\"]/ul/li[5]/a"));
        logout.click();

        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        //Vamos al formulario de logueo.
        driver.navigate().to(URL+"log/delete");
        SeleniumUtils.textIsNotPresentOnPage(driver, "PET");
    }


    // CASOS DE PRUEBA PARA EL PUNTO 19

    //PR37. Como administrador cambiar el estado de una publicacion y comprobar
    // que el estado se actualiza
    @Test
    @Order(37)
    public void PR37() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        // vamos a la lista con todos los posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/post/adminList')]"));
        option.click();
        // cambiamos de estado un post
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[@class=\"moderado\"]");
        elements.get(0).click();
        // comprobamos que se ha cambiado volviendo a cojer los links de moderado que seran uno menos
        elements = PO_View.checkElementBy(driver, "free", "//a[@class=\"moderado\"]");
        Assertions.assertEquals(4, elements.size());
    }

    //PR38. Como usuario comprobar que en su listado de publicaciones no aparece
    // una publicacion censurada
    @Test
    @Order(38)
    public void PR38() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        // vamos a la lista de los posts propios
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/post/list')]"));
        option.click();
        // comprobamos que no está el post
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Post 11",PO_View.getTimeout());
        option = driver.findElement(By.xpath("//*[@id=\"main-container\"]/div[2]/ul/li[3]/a"));
        option.click();
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Post 11",PO_View.getTimeout());
    }

    //PR39. Comprobar en el listado de publicaciones de un amigo, que no aparece una
    // publicación moderada
    @Test
    @Order(39)
    public void PR39() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user13@email.com", "user13");
        // vamos a la lista de posts de los amigos
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/friendship/list')]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/friendship/postslist/145')]"));
        option.click();
        // comprobamos que no está el post
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Post 12",PO_View.getTimeout());
        option = driver.findElement(By.xpath("//*[@id=\"main-container\"]/div[2]/ul/li[3]/a"));
        option.click();
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Post 12",PO_View.getTimeout());
    }

    //PR40. Como usuario estandar, intentar acceder a la opcion de cambio de estado de un post
    @Test
    @Order(40)
    public void PR40() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        // intentamos acceder
        driver.navigate().to(URL+"post/moderado/2");
        // verificamos que estamos en el login
        String checkText = "Identifícate";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR41. Como usuario admin, hacemos una busqueda con cadena vacia y comprobamos
    // que salen todas las publicaciones
    @Test
    @Order(41)
    public void PR41() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        // vamos a la lista con todos los posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/post/adminList')]"));
        option.click();
        // realizamos la busqueda
        option = driver.findElement(By.xpath("//input[@name=\"query\"]"));
        option.clear();
        option.sendKeys("");
        option = driver.findElement(By.xpath("//button[@class=\"btn btn-primary\"]"));
        option.click();
        // comprobamos que estamos en la pagina del listado de publicaciones
        String checkText = "Todas las publicaciones";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR42. hacer una busqueda con un texto que no exista y comprobar que la lista
    // de publicaciones aparece vacia
    @Test
    @Order(42)
    public void PR42() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        // vamos a la lista con todos los posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/post/adminList')]"));
        option.click();
        // realizamos la busqueda
        option = driver.findElement(By.xpath("//input[@name=\"query\"]"));
        option.clear();
        option.sendKeys("ehsw3erag2ew");
        option = driver.findElement(By.xpath("//button[@class=\"btn btn-primary\"]"));
        option.click();
        // comprobamos que la lista esta vacia
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "aceptado",PO_View.getTimeout());
    }

    //PR43. hacer una busqueda con un texto especifico y comprobar que se muestra el
    // post adecuado
    @Test
    @Order(43)
    public void PR43() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        // vamos a la lista con todos los posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_post\"]"));
        option.click();
        option = driver.findElement(By.xpath("//a[contains(@href, '/post/adminList')]"));
        option.click();
        // realizamos la busqueda
        option = driver.findElement(By.xpath("//input[@name=\"query\"]"));
        option.clear();
        option.sendKeys("user14@email.com");
        option = driver.findElement(By.xpath("//button[@class=\"btn btn-primary\"]"));
        option.click();
        // comprobamos que aparecen posts del usuario 14
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//*[@class=\"post\"]");
        Assertions.assertEquals(5, elements.size());
        String checkText = "user14@email.com";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

}
