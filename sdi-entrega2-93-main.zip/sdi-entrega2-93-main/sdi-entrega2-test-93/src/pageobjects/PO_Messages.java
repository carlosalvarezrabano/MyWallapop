package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import util.SeleniumUtils;

import java.sql.Driver;

public class PO_Messages {

    /**
     * Dentro de un chat, envia un mensaje con el texto recibido por parametros
     * @param message mensaje a enviar
     */
    public static void sendMessage(WebDriver driver, String message){
        WebElement input = driver.findElement(By.name("text"));
        input.click();
        input.clear();
        input.sendKeys(message);
        //Pulsar el boton de Alta.
        WebElement boton = driver.findElement(By.name("btn"));
        boton.click();
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'boton-send')]").get(0);
        element.click();
    }
}
