import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.result.DeleteResult;
import org.bson.conversions.Bson;
import org.junit.platform.engine.support.descriptor.FileSystemSource;
import pageobjects.*;
import util.SeleniumUtils;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.bson.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.mongodb.client.model.Filters.*;
import static pageobjects.PO_Messages.sendMessage;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SdiEntrega193ApplicationTests {


    //static String Geckodriver = "C:\\Users\\juann\\Desktop\\uniovi.es\\SDI\\practicas\\trabajo en grupo\\geckodriver-v0.30.0-win64.exe";
    //static String Geckodriver = "C:\\Users\\natal\\Downloads\\PL-SDI-Sesión5-material\\PL-SDI-Sesión5-material\\geckodriver-v0.30.0-win64.exe";
    static String Geckodriver = "C:\\Users\\juann\\Desktop\\uniovi.es\\SDI\\practicas\\trabajo en grupo\\geckodriver-v0.30.0-win64.exe";
    //static String Geckodriver = "C:\\Users\\natal\\Downloads\\PL-SDI-Sesión5-material (1)\\PL-SDI-Sesión5-material\\geckodriver-v0.30.0-win64.exe";
    //static String Geckodriver = "D:\\Users\\Alonso\\Desktop\\Clase\\Uni\\4o Curso - 2021-22\\2o Cuatri\\SDI\\Lab\\Lab05\\PL-SDI-Sesión5-material\\geckodriver-v0.30.0-win64.exe";

    static String PathFirefox = "C:\\Program Files\\Mozilla Firefox\\firefox.exe";
    static WebDriver driver = getDriver(PathFirefox, Geckodriver);
    static String URL = "http://localhost:3000/";
    static MongoClient mgclient;
    static MongoDatabase database;
    public static WebDriver getDriver(String PathFirefox, String Geckodriver) {
        System.setProperty("webdriver.firefox.bin", PathFirefox);
        System.setProperty("webdriver.gecko.driver", Geckodriver);
        driver = new FirefoxDriver();
        return driver;
    }

    static public void crearConexionDB(){
        ConnectionString uri = new ConnectionString("mongodb+srv://admin:sdi123456@cluster0.ofqd9.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
        mgclient = MongoClients.create(uri);
        database = mgclient.getDatabase("sdi-entrega2-93");
        try {
            Bson command = new BsonDocument("ping", new BsonInt64(1));
            Document commandResult = database.runCommand(command);
            System.out.println("Connected successfully to server.");
        } catch (MongoException me) {
            System.err.println("An error occurred while attempting to run a command: " + me);
        }
    }

    @BeforeEach
    public void setUp(){
        driver.navigate().to(URL);
    }

    //Después de cada prueba se borran las cookies del navegador
    @AfterEach
    public void tearDown(){
        driver.manage().deleteAllCookies();
    }

    //Antes de la primera prueba
    @BeforeAll
    static public void begin() {
        crearConexionDB();
    }

    //Al finalizar la última prueba
    @AfterAll
    static public void end() {

        try {
            MongoCollection users = database.getCollection("users");
            users.deleteOne(eq("email", "usertest@email.com"));
            MongoCollection msg = database.getCollection("messages");
            msg.deleteOne(eq("text", "mensaje de test37"));
            msg.deleteOne(eq("text", "mensaje de test37"));
            msg.deleteOne(eq("text", "mensaje de test"));
            msg.deleteOne(eq("text", "mensaje de test"));
            msg.deleteOne(eq("text", "mensaje de test39A"));
            msg.deleteOne(eq("text", "mensaje de test39A"));
            msg.deleteOne(eq("text", "mensaje de test39B"));
            msg.deleteOne(eq("text", "mensaje de test39C"));
            msg.deleteOne(eq("text", "mensaje de test39B"));
            msg.deleteOne(eq("text", "mensaje de test39C"));
            MongoCollection posts = database.getCollection("posts");
            posts.deleteOne(eq("title", "aaaaa"));
        }catch (MongoException e){
            //
        }finally {
            //Cerramos el navegador al finalizar las pruebas
            driver.quit();
            // cerramos la conexion con mongo
            mgclient.close();
        }
    }

    // PRUEBAS DEL PUNTO 1

    //PR01. Prueba del formulario de registro. registro con datos correctos
    @Test
    @Order(1)
    public void PR01() {
        //Vamos al formulario de registro
        PO_HomeView.clickOption(driver, "/users/signup", "class", "btn btn-primary");
        //Rellenamos el formulario.
        String email = "usertest@email.com";
        PO_SignUpView.fillForm(driver, email, "user", "test", "123456", "123456");
        //Comprobamos que entramos en la sección privada y nos muestra el texto a buscar
        String checkText = "Identificación de usuario";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR02. Prueba del formulario de registro. registro con email, nombre y apellidos vacios
    @Test
    @Order(2)
    public void PR02() {
        //Vamos al formulario de registro
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        //Rellenamos el formulario.
        PO_SignUpView.fillForm(driver, "", "", "", "77777", "77777");
        //Comprobamos el error de email vacio.
        List<WebElement> result = PO_SignUpView.checkElementByKey(driver, "email vacio");
        String checkText = "email vacio";
        Assertions.assertEquals(checkText , result.get(0).getText());

        result = PO_SignUpView.checkElementByKey(driver, "nombre o apellidos vacios");
        //Comprobamos el error de nombre vacio.
        checkText = "nombre o apellidos vacios";
        Assertions.assertEquals(checkText , result.get(0).getText());

        result = PO_SignUpView.checkElementByKey(driver, "nombre o apellidos vacios");
        //Comprobamos el error de apellido vacio.
        checkText = "nombre o apellidos vacios";
        Assertions.assertEquals(checkText , result.get(0).getText());
    }


    //PR03. Prueba del formulario de registro. contraseñas no coincidentes.
    // Propiedad: Error.signup.passwordConfirm.coincidence
    @Test
    @Order(3)
    public void PR03() {
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        PO_SignUpView.fillForm(driver, "xml@gmail.com", "JosePerez", "Perez", "666666", "77777");
        List<WebElement> result = PO_SignUpView.checkElementByKey(driver, "contraseñas no coinciden");
        //Comprobamos el error de contraseñas no coincidentes.
        String checkText = "contraseñas no coinciden";
        Assertions.assertEquals(checkText , result.get(0).getText());
    }

    //PR03. Prueba del formulario de registro. Email repetido en la BD
    // Propiedad: Error.signup.email.duplicate
    @Test
    @Order(4)
    public void PR04() {
        PO_HomeView.clickOption(driver, "signup", "class", "btn btn-primary");
        PO_SignUpView.fillForm(driver, "user01@email.com", "user01", "user01", "user01", "user01");
        List<WebElement> result = PO_SignUpView.checkElementByKey(driver, "email repetido");
        //Comprobamos el error de DNI repetido.
        String checkText = "email repetido";
        Assertions.assertEquals(checkText , result.get(0).getText());
    }

    // PRUEBAS DEL PUNTO 2

    //PR05. Prueba de inicio de sesion con datos validos. administrador
    @Test
    @Order(5)
    public void PR05() {
        //Vamos al formulario de logueo.
        WebElement login = PO_View.checkElementBy(driver, "free", "//*[contains(@id, 'login')]").get(0);
        login.click();
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        //Comprobamos que entramos en la pagina privada
        String checkText = "Usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR06. Prueba de inicio de sesion con datos validos. usuario estandar
    @Test
    @Order(6)
    public void PR06() {
        //Vamos al formulario de logueo.
        WebElement login = PO_View.checkElementBy(driver, "free", "//*[contains(@id, 'login')]").get(0);
        login.click();
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "Usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR07. Prueba de inicio de sesion con datos invalidos. email y contraseña vacios
    @Test
    @Order(7)
    public void PR07() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "", "");
        //Comprobamos que no nos logeamos
        String checkText = "Email o password incorrecto";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR08. Prueba de inicio de sesion con datos invalidos. email existente y contraseña invalida
    @Test
    @Order(8)
    public void PR08() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@uniovi.es", "aaa");
        //Comprobamos que entramos en la pagina privada de Alumno
        String checkText = "Email o password incorrecto";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    // PRUEBAS DEL PUNTO 3

    //PR09. Hacer clic en el boton de salir de sesion y comprobar que estamos en la pagina del login
    @Test
    @Order(9)
    public void PR09() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        PO_HomeView.clickOption(driver, "logout", "class", "btn btn-primary");
        //Comprobamos que nos conectamos, nos desconectamos y estamos de nuevo en la pagina de login
        String checkText = "Identifícate";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR10. comprobar que el boton de logout no esta disponible si el usuario no esta autenticado
    @Test
    @Order(10)
    public void PR10() {
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Cerrar sesión",PO_View.getTimeout());
    }

    // PRUEBAS DEL PUNTO 4

    //PR11. mostrar el listado de usuarios y comprobar que salen todos los del sistema
    @Test
    @Order(11)
    public void PR11() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'adminList')]");
        elements.get(0).click();
        // seleccionamos las filas de la tabla
        elements = PO_View.checkElementBy(driver, "free", "//*[@class=\"user\"]");
        long users = elements.size();
        long res = database.getCollection("users").estimatedDocumentCount();
        Assertions.assertEquals(res, users);
    }

    // PRUEBAS DEL PUNTO 5


    //PR12. borrar el primer usuario de la lista de usuarios
    @Test
    @Order(12)
    public void PR12() {
        Document user = new Document()
                .append("name", "aaaa")
                .append("lastname", "aaaa")
                .append("email", "aaaa@email.com")
                .append("password", "783a825ecf667676312bdd5e76a138e61e55d5061ef541f445e0c22e671eba9f");
        // introducir al usuario para borrarlo
        MongoCollection usersDB = database.getCollection("users");
        usersDB.insertOne(user);
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'adminList')]");
        elements.get(0).click();
        // seleccionamos el primer usuario
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'aaaa')]").get(0);
        element.click();
        // borramos el primer usuario
        element = PO_View.checkElementBy(driver, "free", "//*[@id=\"borrar\"]").get(0);
        element.click();
        element.click();
        // comprobamos que no aparece el primer usuario
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "aaaa@email.com",PO_View.getTimeout());
    }

    //PR13. borrar el último usuario de la lista de usuarios
    @Test
    @Order(13)
    public void PR13() {
        MongoCollection usersDB = database.getCollection("users");
        Document user = new Document()
                .append("name", "zzzz")
                .append("lastname", "zzzz")
                .append("email", "zzzz@email.com")
                .append("password", "d2aec6988857be3f6ba6781ce63670513864190eb7e88a225ae80be03e6faee8");
        usersDB.insertOne(user);
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'adminList')]");
        elements.get(0).click();
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Todos los usuarios", 10);
        // seleccionamos el primer usuario
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'zzzz')]").get(0);
        element.click();
        // borramos el ultimo usuario
        element = PO_View.checkElementBy(driver, "free", "//*[@id=\"borrar\"]").get(0);
        element.click();
        // comprobamos que no aparece el primer usuario
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "zzzz@email.com",PO_View.getTimeout());
    }

    //PR14. borrar 3 usuarios y comprobar que la lista se actualiza
    @Test
    @Order(14)
    public void PR14() {
        MongoCollection usersDB = database.getCollection("users");
        Document user = new Document()
                .append("name", "test1")
                .append("lastname", "test1")
                .append("email", "test1@email.com")
                .append("password", "c4307e1f4f7a11e99a5e4bfeaf598cadcb99fc536b6eeb668ebdff87df88cff5");
        usersDB.insertOne(user);
        user = new Document()
                .append("name", "test2")
                .append("lastname", "test2")
                .append("email", "test2@email.com")
                .append("password", "b9809187151d1b2ada397b7c6ecfdedcaeeaa401568f7abf4706b7eab2f7f8b6");
        usersDB.insertOne(user);
        user = new Document()
                .append("name", "test3")
                .append("lastname", "test3")
                .append("email", "test3@email.com")
                .append("password", "6fc8f37f8afb07a2aadeb9d6a81df0c4f3fe8d62ed7f41d8a6b0d797011c310c");
        usersDB.insertOne(user);
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "admin@email.com", "admin");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'adminList')]");
        elements.get(0).click();
        // seleccionamos tres usuarios
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'test1')]").get(0);
        element.click();
        element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'test2')]").get(0);
        element.click();
        element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'test3')]").get(0);
        element.click();
        // borramos el primer usuario
        element = PO_View.checkElementBy(driver, "free", "//*[@id=\"borrar\"]").get(0);
        element.click();
        // comprobamos que no aparece el primer usuario
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "test1@email.com",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "test2@email.com",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "test3@email.com",PO_View.getTimeout());
    }

    // PRUEBAS DEL PUNTO 6

    //PR15. mostrar el listado de usuarios y comprobar que salen todos los del sistema menos el propio usuario
    // y el administrador
    @Test
    @Order(15)
    public void PR15() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_user\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'users/list')]");
        elements.get(0).click();
        // seleccionamos las paginas disponibles
        List<WebElement> paginas = PO_View.checkElementBy(driver, "free", "//*[@class=\"page-link\"]");
        // recorremos las paginas contando los usuarios y mirando que no esten ni el admin ni el propio usuario
        int numUsers = 0;
        List<WebElement> usuarios;
        for(int i = 0; i < paginas.size(); i++){
            paginas.get(i).click();
            paginas = PO_View.checkElementBy(driver, "free", "//*[@class=\"page-link\"]");
            usuarios = PO_View.checkElementBy(driver, "free", "//*[@class=\"user\"]");
            numUsers += usuarios.size();
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user01@email.com",PO_View.getTimeout());
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "admin@email.com",PO_View.getTimeout());
        }
        long res = database.getCollection("users").estimatedDocumentCount() -2;
        Assertions.assertEquals(res, numUsers);
    }

    //PRUEBAS DEL PUNTO 7

    //PR16. Hacer una búsqueda con el campo vacío y comprobar que se muestra la página que
    //corresponde con el listado usuarios existentes en el sistema
    @Test
    @Order(16)
    public void PR16() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        //Presionamos el boton de buscar y comprobamos que sale la lista completa de usuarios
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();

        // seleccionamos las paginas disponibles
        List<WebElement> paginas = PO_View.checkElementBy(driver, "free", "//*[@class=\"page-link\"]");
        // recorremos las paginas contando los usuarios y mirando que no esten ni el admin ni el propio usuario
        int numUsers = 0;
        List<WebElement> usuarios;
        for(int i = 0; i < paginas.size(); i++){
            paginas.get(i).click();
            paginas = PO_View.checkElementBy(driver, "free", "//*[@class=\"page-link\"]");
            usuarios = PO_View.checkElementBy(driver, "free", "//*[@class=\"user\"]");
            numUsers += usuarios.size();
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user01@email.com",PO_View.getTimeout());
            SeleniumUtils.waitTextIsNotPresentOnPage(driver, "admin@email.com",PO_View.getTimeout());
        }
        long res = database.getCollection("users").estimatedDocumentCount() -2;
        Assertions.assertEquals(res, numUsers);
    }

    //PR17. Hacer una búsqueda escribiendo en el campo un texto que no exista y comprobar que se
    //muestra la página que corresponde, con la lista de usuarios vacía
    @Test
    @Order(17)
    public void PR17() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Usuarios de la red social:", 10);
        //Nos situamos en el buscador de usuarios y lo dejamos en blanco
        WebElement searchText = driver.findElement(By.name("search"));
        searchText.click();
        searchText.clear();
        searchText.sendKeys("noexiste");
        //Presionamos el boton de buscar y comprobamos que sale la lista vacia
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();

        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "1",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "2",PO_View.getTimeout());
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "3",PO_View.getTimeout());
    }

    //PR18. Hacer una búsqueda con un texto específico y comprobar que se muestra la página que
    //corresponde, con la lista de usuarios en los que el texto especificado sea parte de su nombre, apellidos o
    //de su email
    @Test
    @Order(18)
    public void PR18() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        //Nos situamos en el buscador de usuarios y buscamos un usuario
        WebElement searchText = driver.findElement(By.name("search"));
        searchText.click();
        searchText.clear();
        searchText.sendKeys("user12");
        //Presionamos el boton de buscar y comprobamos que sale dicho usuario
        By boton = By.className("btn");
        driver.findElements(boton).get(0).click();
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user12", 10);
        List<WebElement> usuarios = PO_View.checkElementBy(driver, "free", "//*[@class=\"user\"]");
        Assertions.assertEquals(1, usuarios.size());
        SeleniumUtils.textIsPresentOnPage(driver, "user12@email.com");
    }

    //PR19. Desde el listado de usuarios de la aplicación, enviar una invitación de amistad a un usuario.
    //Comprobar que la solicitud de amistad aparece en el listado de invitaciones (punto siguiente).
    @Test
    @Order(19)
    public void PR19() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        //Aquí estamos en el listado de usuarios, vemos que está el "Agregar amigo"
        List<WebElement> result = PO_View.checkElementBy(driver, "text", "Agregar amigo");
        Assertions.assertEquals("Agregar amigo",result.get(0).getText());
        //Presiono en el primer usuario
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequests/add')]");
        elements.get(0).click();
        //borro la solicitud
        BsonDocument bson = BsonDocument.parse("{\n" +
                "\"friend1email\":\"user14@email.com\",\n" +
                "\"friend2email\":\"user02@email.com\"\n" +
                "}");
        database.getCollection("friendRequests").deleteOne(bson);
    }


    //PR20. Desde el listado de usuarios de la aplicación, enviar una invitación de amistad a un usuario al
    //que ya le habíamos enviado la invitación previamente. No debería dejarnos enviar la invitación, se podría
    //ocultar el botón de enviar invitación o notificar que ya había sido enviada previamente.
    //En nuestro caso, no aparece el botón. Aparece texto indicando que ya se ha enviado
    @Test
    @Order(20)
    public void PR20() {
        //Inserto la solicitud
        MongoCollection friendRequestsDB = database.getCollection("friendRequests");
        Document fr = new Document()
                .append("friend1email", "user14@email.com")
                .append("friend2email", "user02@email.com");
        friendRequestsDB.insertOne(fr);
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user14@email.com", "user14");
        //Aquí estamos en el listado de usuarios, vemos que está el "Solicitud ya enviada"
        List<WebElement> result = PO_View.checkElementBy(driver, "text", "Solicitud ya enviada");
        Assertions.assertEquals("Solicitud ya enviada",result.get(0).getText());
        //Borro la solicitud para que el test no falle la próxima vez
        BsonDocument bson = BsonDocument.parse("{\n" +
                "\"friend1email\":\"user14@email.com\",\n" +
                "\"friend2email\":\"user02@email.com\"\n" +
                "}");
        database.getCollection("friendRequests").deleteOne(bson);
    }


    //PR21. Mostrar el listado de invitaciones de amistad recibidas. Comprobar con un listado que
    //contenga varias invitaciones recibidas.
    @Test
    @Order(21)
    public void PR21() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Usuarios de la red social:", 10);
        //Aquí estamos en el listado de usuarios, voy a la opcion de mis solicitudes recibidas
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_friendRequest\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequests/list')]");
        elements.get(0).click();

        List<WebElement> users = PO_View.checkElementBy(driver, "free", "/html/body/div/div/table/tbody/tr");
        // recorremos las paginas contando los usuarios
        int numUsers = 0;
        for(int i = 0; i < users.size(); i++){
            numUsers ++;
        }
        long res = database.getCollection("friendRequests").countDocuments(
                eq("friend2email","user02@email.com")
        );

        Assertions.assertEquals(numUsers+"", res+"");

    }

    //PR22. Sobre el listado de invitaciones recibidas. Hacer clic en el botón/enlace de una de ellas y
    //comprobar que dicha solicitud desaparece del listado de invitaciones.
    @Test
    @Order(22)
    public void PR22() {
        //Envio una peticion del usuario 2 al 4 para esta prueba
        MongoCollection friendRequestsDB = database.getCollection("friendRequests");
        Document fr = new Document()
                .append("friend1email", "user02@email.com")
                .append("friend2email", "user04@email.com");
        friendRequestsDB.insertOne(fr);
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user04@email.com", "user04");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        //Aquí estamos en el listado de usuarios, voy a la opcion de mis solicitudes recibidas
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_friendRequest\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendRequests/list')]");
        elements.get(0).click();
        //Desde aqui, acepto la peticion
        List<WebElement> result = PO_View.checkElementBy(driver, "text", "Aceptar solicitud");
        Assertions.assertEquals("Aceptar solicitud",result.get(0).getText());
        //Presiono en el primer usuario
        elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, '/friendships/add/')]");
        elements.get(0).click();

        SeleniumUtils.waitLoadElementsBy(driver, "text", "Peticiones de amistad:", 10);
        //Voy al listado de amigos
        option = driver.findElement(By.xpath("//*[@id=\"dropdown_friendships\"]"));
        option.click();
        elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendships/list')]");
        elements.get(0).click();

        //Compruebo que sale el user02
        SeleniumUtils.textIsPresentOnPage(driver, "user02");

        //Borro la amistad
        BsonDocument bson = BsonDocument.parse("{\n" +
                "\"friend1email\":\"user02@email.com\",\n" +
                "\"friend2email\":\"user04@email.com\"\n" +
                "}");
        database.getCollection("friendships").deleteOne(bson);
    }


    //PR23. Mostrar el listado de amigos de un usuario. Comprobar que el listado contiene los amigos que 
    //deben ser.
    @Test
    @Order(23)
    public void PR23() {
        //Hago una amistad entre el 2 y el 4 y el 3 y 4 para la prueba
        MongoCollection friendRequestsDB = database.getCollection("friendships");
        Document fr = new Document()
                .append("friend1email", "user02@email.com")
                .append("friend2email", "user04@email.com");
        friendRequestsDB.insertOne(fr);
        fr = new Document()
                .append("friend1email", "user03@email.com")
                .append("friend2email", "user04@email.com");
        friendRequestsDB.insertOne(fr);
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user04@email.com", "user04");
        //Voy al listado de amigos
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_friendships\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'friendships/list')]");
        elements.get(0).click();

        //Compruebo que sale el user02
        SeleniumUtils.textIsPresentOnPage(driver, "user02");

        //Borro las amistades
        BsonDocument bson = BsonDocument.parse("{\n" +
                "\"friend1email\":\"user02@email.com\",\n" +
                "\"friend2email\":\"user04@email.com\"\n" +
                "}");
        database.getCollection("friendships").deleteOne(bson);
        bson = BsonDocument.parse("{\n" +
                "\"friend1email\":\"user03@email.com\",\n" +
                "\"friend2email\":\"user04@email.com\"\n" +
                "}");
        database.getCollection("friendships").deleteOne(bson);
    }

    //PR24.Ir al formulario crear publicaciones, rellenarla con datos válidos y pulsar el botón Submit.
    //Comprobar que la publicación sale en el listado de publicaciones de dicho usuario
    @Test
    @Order(24)
    public void PR24() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user15@email.com", "user15");
        //Voy al formulario de crear posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_posts\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'posts/add')]");
        elements.get(0).click();
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Título:", 10);
        // rellenamos el formulario
        WebElement input = driver.findElement(By.name("title"));
        input.click();
        input.clear();
        input.sendKeys("aaaaa");
        input = driver.findElement(By.name("texto"));
        input.click();
        input.clear();
        input.sendKeys("aaaaa");
        //Pulsar el boton de Alta.
        WebElement boton = driver.findElement(By.name("agregar"));
        boton.click();
        SeleniumUtils.waitLoadElementsBy(driver, "text", "My posts", 10);
        SeleniumUtils.waitLoadElementsBy(driver, "text", "aaaaa", 10);
    }

    //PR25.Ir al formulario de crear publicaciones, rellenarla con datos inválidos (campo título vacío) y
    //pulsar el botón Submit. Comprobar que se muestra el mensaje de campo obligatorio.
    @Test
    @Order(25)
    public void PR25() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user01@email.com", "user01");
        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "Identificación de usuario", 10);
        //Voy al formulario de crear posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_posts\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, 'posts/add')]");
        elements.get(0).click();
        // rellenamos el formulario con campo y titulo vacios
        WebElement input = driver.findElement(By.name("title"));
        input.click();
        input.clear();
        input.sendKeys("");
        input = driver.findElement(By.name("texto"));
        input.click();
        input.clear();
        input.sendKeys("");
        //Pulsar el boton de Alta.
        WebElement boton = driver.findElement(By.name("agregar"));
        boton.click();
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Titulo o texto vacio", 10);
    }

    //PR26.Mostrar el listado de publicaciones de un usuario y comprobar que se muestran todas las que
    //existen para dicho usuario.
    @Test
    @Order(26)
    public void PR26() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user15@email.com", "user15");
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Usuarios de la red social:", 10);
        // voy a ver mis posts
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_posts\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, '/posts')]");
        elements.get(0).click();
        SeleniumUtils.waitLoadElementsBy(driver, "text","My posts", 10);
        // cojo los posts
        List<WebElement> posts = PO_View.checkElementBy(driver, "free", "//*[contains(@class,'post')]");
        long res = database.getCollection("posts").countDocuments(
                eq("usuario","user15@email.com")
        );
        Assertions.assertEquals(res+"", posts.size()+"");
    }

    //PR27.Mostrar el listado de publicaciones de un usuario amigo y comprobar que se muestran todas
    //las que existen para dicho usuario
    @Test
    @Order(27)
    public void PR27() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user02@email.com", "user02");
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Usuarios de la red social:", 10);
        // voy a mis amigos
        WebElement option = driver.findElement(By.xpath("//*[@id=\"dropdown_friendships\"]"));
        option.click();
        List<WebElement> elements = PO_View.checkElementBy(driver, "free", "//a[contains(@href, '/friendships/list')]");
        elements.get(0).click();
        SeleniumUtils.waitLoadElementsBy(driver, "text","Mis amigos:", 10);
        // meterme en el user01
        elements = PO_View.checkElementBy(driver, "free", "//a[contains(@id, 'user07')]");
        elements.get(0).click();
        SeleniumUtils.waitLoadElementsBy(driver, "text","Posts", 10);
        // cojo los posts
        List<WebElement> posts = PO_View.checkElementBy(driver, "free", "//*[contains(@class,'post')]");
        long res = database.getCollection("posts").countDocuments(
                eq("usuario","user07@email.com")
        );
        Assertions.assertEquals(res+"", posts.size()+"");
    }

    //PR28.Utilizando un acceso vía URL u otra alternativa, tratar de listar las publicaciones de un usuario
    //que no sea amigo del usuario identificado en sesión. Comprobar que el sistema da un error de autorización.
    @Test
    @Order(28)
    public void PR28() {
        //Vamos al formulario de logueo.
        PO_HomeView.clickOption(driver, "login", "class", "btn btn-primary");
        //Rellenamos el formulario
        PO_LoginView.fillLoginForm(driver, "user16@email.com", "user16");
        driver.navigate().to("http://localhost:3000/posts/list/625495107830a390e347b234");

        String checkText = "Error de autorización";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR29.Intentar acceder sin estar autenticado a la opción de listado de usuarios. Se deberá volver al
    //formulario de login.
    @Test
    @Order(29)
    public void PR29() {
        // accedo sin estar autenticado
        driver.navigate().to("http://localhost:3000/users/list");

        String checkText = "Identificación de usuario";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR30.Intentar acceder sin estar autenticado a la opción de listado de invitaciones de amistad recibida
    //de un usuario estándar. Se deberá volver al formulario de login.
    @Test
    @Order(30)
    public void PR30() {
        // accedo sin estar autenticado
        driver.navigate().to("http://localhost:3000/friendRequests/list");

        String checkText = "Identificación de usuario";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

  //PR32. Inicio de sesión con datos válidos.
    @Test
    @Order(32)
    public void PR32() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR33. Inicio de sesión con datos inválidos (usuario no existente en la aplicación).
    @Test
    @Order(33)
    public void PR33() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "noexiste@email.com", "noexiste");
        //Comprobamos que entramos en la pagina privada
        String checkText = "Usuario no encontrado";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
    }

    //PR34. Acceder a la lista de amigos de un usuario, que al menos tenga tres amigos.
    @Test
    @Order(34)
    public void PR34() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        List<WebElement> element = PO_View.checkElementBy(driver, "free", "//*[contains(@class,'user')]");
        long res = database.getCollection("friendships").countDocuments(
                or(
                        eq("friend1email","user01@email.com"),
                        eq("friend2email","user01@email.com")
                )
        );
        Assertions.assertEquals(res+"", element.size()+"");
    }

    //PR35. Acceder a la lista de amigos de un usuario, y realizar un filtrado para encontrar a un amigo
    //concreto, el nombre a buscar debe coincidir con el de un amigo.
    @Test
    @Order(35)
    public void PR35() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        SeleniumUtils.waitLoadElementsBy(driver, "text", "Email:", 10);
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user08", PO_View.getTimeout());

        WebElement password = driver.findElement(By.name("search"));
        password.click();
        password.clear();
        password.sendKeys("user08");
        //Pulsar el boton de Alta.
        WebElement boton = driver.findElement(By.name("btn"));
        boton.click();

        SeleniumUtils.waitTextIsNotPresentOnPage(driver, "user02", 10);
        List<WebElement> element = PO_View.checkElementBy(driver, "free", "//*[contains(@class,'user')]");
        Assertions.assertEquals(1, element.size());
    }

    //PR36. Acceder a la lista de mensajes de un amigo, la lista debe contener al menos tres mensajes.
    @Test
    @Order(36)
    public void PR36() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user08", PO_View.getTimeout());

        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'messageuser08')]").get(0);
        element.click();
        List<WebElement> msgs = PO_View.checkElementBy(driver, "free", "//*[contains(@class,'msg')]");
        Assertions.assertEquals(3, msgs.size());
    }

    //PR37.  Acceder a la lista de mensajes de un amigo y crear un nuevo mensaje. Validar que el mensaje
    //aparece en la lista de mensajes
    @Test
    @Order(37)
    public void PR37() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user08", PO_View.getTimeout());

        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'messageuser08')]").get(0);
        element.click();

        WebElement password = driver.findElement(By.name("text"));
        password.click();
        password.clear();
        password.sendKeys("mensaje de test37");
        //Pulsar el boton de Alta.
        WebElement boton = driver.findElement(By.name("btn"));
        boton.click();
        boton.click();
        SeleniumUtils.waitLoadElementsBy(driver, "text","mensaje de test37", 15);
    }

    //PR38.Identificarse en la aplicación y enviar un mensaje a un amigo. Validar que el mensaje enviado
    //aparece en el chat. Identificarse después con el usuario que recibió el mensaje y validar que tiene un
    //mensaje sin leer. Entrar en el chat y comprobar que el mensaje pasa a tener el estado leído
    @Test
    @Order(38)
    public void PR38() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user08", 10);
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'messageuser08')]").get(0);
        element.click();
        List<WebElement> msgs = PO_View.checkElementBy(driver, "free", "//*[contains(@class,'msg')]");
        // mandamos el mensaje
        PO_Messages.sendMessage(driver, "mensaje de test");
        SeleniumUtils.waitLoadElementsBy(driver, "text","mensaje de test", 10);

        //logout
        WebElement boton = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'logout')]").get(0);
        boton.click();
        PO_LoginView.fillLoginFormAPI(driver, "user08@email.com", "user08");
        //Comprobamos que entramos en la pagina privada
        checkText = "usuarios de la red social:";
        result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user01", 10);
        element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'messageuser01')]").get(0);
        element.click();
        SeleniumUtils.waitLoadElementsBy(driver, "text","mensaje de test ~leido~", 10);
    }

    //PR39. Identificarse en la aplicación y enviar tres mensajes a un amigo. Validar que los mensajes
    //enviados aparecen en el chat. Identificarse después con el usuario que recibido el mensaje y validar que el
    //número de mensajes sin leer aparece en la propia lista de amigos.
    @Test
    @Order(39)
    public void PR39() {
        driver.navigate().to("http://localhost:3000/apiClient/client.html");
        SeleniumUtils.waitLoadElementsBy(driver,"text", "Email:",10);
        //Rellenamos el formulario
        PO_LoginView.fillLoginFormAPI(driver, "user01@email.com", "user01");
        //Comprobamos que entramos en la pagina privada
        String checkText = "usuarios de la red social:";
        List<WebElement> result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user08", PO_View.getTimeout());
        WebElement element = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'messageuser08')]").get(0);
        element.click();

        // mandamos 3 mensajes
        PO_Messages.sendMessage(driver, "mensaje de test39A");
        SeleniumUtils.waitLoadElementsBy(driver, "text","mensaje de test39A", 15);
        PO_Messages.sendMessage(driver,"mensaje de test39B");
        SeleniumUtils.waitLoadElementsBy(driver, "text","mensaje de test39B", 15);
        PO_Messages.sendMessage(driver, "mensaje de test39C");
        SeleniumUtils.waitLoadElementsBy(driver, "text","mensaje de test39C", 15);

        //logout
        WebElement logout = PO_View.checkElementBy(driver, "free", "//*[contains(@id,'logout')]").get(0);
        logout.click();
        PO_LoginView.fillLoginFormAPI(driver, "user08@email.com", "user08");
        //Comprobamos que entramos en la pagina privada
        checkText = "usuarios de la red social:";
        result = PO_View.checkElementBy(driver, "text", checkText);
        Assertions.assertEquals(checkText, result.get(0).getText());
        SeleniumUtils.waitLoadElementsBy(driver, "text", "user01", PO_View.getTimeout());
        // comprobamos que hay 3 mensajes sin leer
        MongoCollection msg = database.getCollection("messages");
        FindIterable<Document> msgs = msg.find(
                and(
                        eq("sender", "user01@email.com"),
                        eq("receiver", "user08@email.com"),
                        eq("checked", false)
                )
        );
        int size = 0;
        for (Object i : msgs) {
            size++;
        }
        SeleniumUtils.waitLoadElementsBy(driver, "text",size+"", 15);
    }

}
