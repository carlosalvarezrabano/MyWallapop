const {ObjectId} = require("mongodb");
module.exports = function (app, friendRequestsRepository, usersRepository, friendshipsRepository, logger) {

    /**
     * Crea una amistad entre el usuario logeado y otro cuya id
     * se recibe en el endpoint.
     */
    app.get('/friendships/add/:id', function(req, res) {
        let friend2= req.session.user; //user08
        //el que acepta es el de sesion, el 2. Borro la request donde el emailacepta 2 es el friend2email

        if (req.session.user==null) {
            res.status(404);
            res.json({error: "Error: no se puede añadir una amistad sin login"});
        } else {

        let filter1 = {_id: ObjectId(req.params.id)}
        //Encuentro al usuario
        usersRepository.findUser(filter1, {}).then(user => { //1 es 01. 2 es 08
            if (user==null) {
                res.status(404);
                res.json({error: "Error: no se puede añadir una amistad"});
            } else {
                //Añado la amistad
                let frienship = {
                    friend1email: user.email,
                    friend2email: friend2
                }

                if (friend2==null) {
                        res.status(404);
                        res.json({error: "Error: no se puede añadir una amistad"});
                } else {
                //Añado la amistad
                friendshipsRepository.add(frienship).then(friendshipID => {
                    //Encuentro el id de la peticion
                    let filterFind = {friend1email: user.email, friend2email: friend2}
                    friendRequestsRepository.findRequest(filterFind, {}).then(request => {
                        if (request == null) {
                            res.status(404);
                            res.json({error: "Error al añadir amistad"});
                        } else {
                            let filterRemove = {_id: ObjectId(request._id)};
                            //Borro la peticion
                            friendRequestsRepository.deleteRequest(filterRemove, {}).then(r => {
                                logger.debug("Nueva amistad de " + req.session.user + " y " + friend2);
                                res.redirect("/friendRequests/list");
                            });
                        }
                    });

                });}
            }
        }); }

    });

    /**
     * Devuelve la vista con el listado de amigos del usuario logeado.
     */
    app.get('/friendships/list', function(req, res) {

        if (req.session.user==null) {
            res.redirect("/users/login")
        } else {

            let page = parseInt(req.query.page); // Es String
            if (typeof req.query.page === "undefined" || req.query.page === null || req.query.page === "0") { //Puede no venir el param
                page = 1;
            }
            let filter = {$or: [{friend1email: req.session.user}, {friend2email: req.session.user}]}
            friendshipsRepository.getFriendsByUser(filter, {}).then(result => {
                let friends = []
                usersRepository.getUsers({}, {}).then(users => {
                    users.forEach(user => {
                        result.forEach(a => {
                            if (user.email != req.session.user && (user.email === a.friend1email || user.email === a.friend2email)) {
                                friends.push(user);
                            }
                        })
                    })
                    let limit = 5;
                    let total = friends.length;
                    let lastPage = total / 5;
                    if (total % 5 > 0) { // Sobran decimales
                        lastPage = lastPage + 1;
                    }
                    let pages = []; // paginas mostrar
                    for (let i = page - 2; i <= page + 2; i++) {
                        if (i > 0 && i <= lastPage) {
                            pages.push(i);
                        }
                    }
                    logger.debug("Listado de amistades de " + req.session.user);

                    res.render('friendships/list', {
                        users: friends.slice((page - 1) * limit, limit * page),
                        pages: pages,
                        currentPage: page,
                        logged: req.session.logged
                    });
                });
            });
        }
    });


};