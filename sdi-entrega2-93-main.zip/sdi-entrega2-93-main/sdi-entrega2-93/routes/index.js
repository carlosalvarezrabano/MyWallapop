module.exports = function (app) {

    /**
     * punto de entrada inicial para la página.
     */
    app.get('/', function (req, res) {
        res.render("index.twig", {title: "Red Social SDI", logged: req.session.logged});
    });

};
