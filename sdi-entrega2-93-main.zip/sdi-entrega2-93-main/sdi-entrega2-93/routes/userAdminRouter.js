const express = require('express');
const userAdminRouter = express.Router();

/**
 * Deja correr la petición solo si el usuario esta logeado
 * como administrador
 */
userAdminRouter.use(function(req, res, next) {
    console.log("routerUsuarioSession");
    if ( req.session.user === "admin@email.com" ) {
        // dejamos correr la petición
        next();
    } else {
        console.log("va a: " + req.originalUrl);
        req.session.user = null;
        res.redirect("/users/login");
    }
});
module.exports = userAdminRouter;