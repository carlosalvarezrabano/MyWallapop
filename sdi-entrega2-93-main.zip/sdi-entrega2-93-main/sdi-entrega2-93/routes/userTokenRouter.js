const jwt = require("jsonwebtoken");
const express = require('express');
const userTokenRouter = express.Router();

/**
 * Deja correr la petición solo si existe una cabecera llamada token y este
 * no ha caducado
 */
userTokenRouter.use(function (req, res, next) {
    let token = req.headers['token'] || req.body.token || req.query.token;
    if (token != null) {
        jwt.verify(token, 'secreto', {}, function (err, infoToken) {
            if (err || (Date.now() / 1000 - infoToken.time) > 240) {
                res.status(403);
                res.redirect('/api/v1.0/users/login');
            } else {
                res.user = infoToken.user;
                next();
            }
        });
    } else {
        res.status(403);
        res.redirect('/api/v1.0/users/login');
    }
});
module.exports = userTokenRouter;