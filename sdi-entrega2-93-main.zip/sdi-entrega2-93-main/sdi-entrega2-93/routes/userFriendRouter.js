const express = require('express');
const {ObjectId} = require("mongodb");
const userFriendRouter = express.Router();
const friendshipsRepository = require("../repositories/friendshipsRepository");
const usersRepository = require("../repositories/usersRepository");
const path = require("path");

/**
 * Comprueba que que el usuario que esta accediendo a la lista de post de otro es su amigo
 */
userFriendRouter.use(function(req, res, next) {
    console.log("routerFriendUser");

    let id = path.basename(req.originalUrl);
    let email = req.session.user;
    usersRepository.findUser({_id: ObjectId(id)},{}).then(friend => {
        if(friend != null){
            let filter = {
                $or:[
                    {$and:[{friend1email: friend.email},{friend2email: email}]},
                    {$and:[{friend1email: email},{friend2email: friend.email}]}
                ]
            }
            friendshipsRepository.getFriendsByUser(filter,{}).then(amistad => {
                if(amistad.length !== 0){
                    // dejamos correr la petición
                    next();
                }else{
                    req.session.user=null;
                    res.send("Error de autorización");
                }
            })
        }else{
            req.session.user=null;
            res.redirect("/users/login");
        }
    });
});
module.exports = userFriendRouter;