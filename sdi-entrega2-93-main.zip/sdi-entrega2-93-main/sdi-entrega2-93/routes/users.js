const {ObjectId} = require("mongodb");
const postsRepository = require("../repositories/postsRepository");
const messagesRepository = require("../repositories/messagesRepository");
module.exports = function (app, usersRepository, friendshipsRepository, friendRequestsRepository, logger , postsRepository, messagesRepository) {

    /**
     * Devuelve la vista con el formulario de registro
     */
    app.get('/users/signup', function (req, res) {
        if(req.session.user){
            res.redirect("/users/list");
        }else {
            let err = req.query.errors;
            if(err){
                res.render("signup.twig", JSON.parse(err));
            }else {
                res.render("signup.twig");
            }
        }
    });

    /**
     * Añade a un usuario en el sistema
     */
    app.post('/users/signup', function (req, res) {
        let securePassword = app.get("crypto").createHmac('sha256', app.get('clave'))
            .update(req.body.password).digest('hex');
        let errors = [];
        let user = {
            name: req.body.name,
            lastname: req.body.lastname,
            email: req.body.email,
            password: securePassword
        }
        if(req.body.password !== req.body.confirmpassword) {
            errors.push("contraseñas no coinciden");
        }
        if(req.body.email === 'admin@email.com'){
            errors.push("email invalido");
        }
        if(req.body.name === "" || req.body.lastname === ""){
            errors.push("nombre o apellidos vacios");
        }
        if(req.body.email === ""){
            errors.push("email vacio");
        }
        usersRepository.findUser({email: req.body.email}).then((userFromBD) => {
            if (userFromBD != null) {
                errors.push("email repetido");
            }
            if(errors.length > 0){
                let error = {errors: errors};
                res.redirect("/users/signup?errors="+JSON.stringify(error));
            }else {
                usersRepository.insertUser(user).then(userId => {
                    logger.debug("Usuario registrado con email " + req.body.email);
                    res.redirect('/users/login');
                }).catch(error => {
                    res.send("Error al insertar el usuario: " + error);
                });
            }
        }).catch(error => {
            res.send("Se ha producido un error en el registro: " + error);
        });
    });

    /**
     * Devuelve la vista con el formulario para ingresar en el sistema.
     */
    app.get('/users/login', function (req, res) {
        if(req.session.user){
            res.redirect("/users/list");
        }else {
            res.render("login.twig");
        }
    });

    /**
     * Permite ingresar en el sistema creando una sesión.
     */
    app.post('/users/login', function (req, res){
        let securePassword = app.get("crypto").createHmac('sha256',app.get('clave'))
            .update(req.body.password).digest('hex');
        let filter = {
            email: req.body.email,
            password: securePassword
        }
        let options = {}
        usersRepository.findUser(filter, options).then(user => {
            if(user == null) {
                req.session.user = null;
                res.redirect("/users/login" +
                    "?message=Email o password incorrecto"+
                    "&messageType=alert-danger ");
            } else {
                req.session.user = user.email;
                if(req.body.email == "admin@email.com"){
                    req.session.logged = "admin";
                }else{
                    req.session.logged = "user";
                }
                logger.debug("Usuario logeado con email " + user.email);
                res.redirect("/users/list");
            }
        }).catch(err => {
            req.session.user = null;
            res.redirect("/users/login" +
                "?message=Se ha producido un error al buscar el usuario"+
                "&messageType=alert-danger ");
        });
    });

    /**
     * Permite cerrar sesión en el sistema.
     */
    app.get('/users/logout', function (req, res) {
        logger.debug("Logout de usuario con email " + req.session.user);
        req.session.user = null;
        req.session.logged = "";
        res.redirect("/users/login");
    });

    /**
     * Devuelve la vista con la lista de usuarios de la aplicación.
     */
    app.get('/users/list', function (req, res) {
        let admin=false

        let page = parseInt(req.query.page); // Es String
        if (typeof req.query.page === "undefined" || req.query.page === null || req.query.page === "0") { //Puede no venir el param
            page = 1;
        }
        let filter = {$and: [{email:{$not:{$eq: 'admin@email.com'}}},{email:{$not:{$eq: req.session.user}}}]}
        if(req.query.search){
            filter = {$and: [
                    {email:{$not:{$eq: 'admin@email.com'}}},
                    {email:{$not:{$eq: req.session.user}}},
                    {$or: [{email: {$regex: req.query.search}}, {name: {$regex: req.query.search}}, {lastname: {$regex: req.query.search}}]}
                ]};
        }
        usersRepository.getUsersPage(filter,{},page).then((result) => {
            let lastPage = result.total / 5;
            if (result.total % 5 > 0) { // Sobran decimales
                lastPage = lastPage + 1;
            }
            let pages = []; // paginas mostrar
            for (let i = page - 2; i <= page + 2; i++) {
                if (i > 0 && i <= lastPage) {
                    pages.push(i);
                }
            }
            let response;



            //Parte solicitud de amistad

            //tengo que pasar misSolicitudes , y misAmigos

            //tod con ids
            //devuelvo lista con los ids de mis amigos y con los de la
            //gente a la que mande solicitud

            let filter2 = {friend1email: req.session.user }

            let options2 = { friend2email: 1}


            friendshipsRepository.getFriendsByUser(filter2, options2).then(misAmigos1 => {

                let filter3 = {friend2email: req.session.user }

                let options3 = { friend1email: 1}

                friendshipsRepository.getFriendsByUser(filter3, options3).then(misAmigos2 => {

                    friendRequestsRepository.getSolicitudes(filter2, options2).then(misSolicitudes => {

                        //array
                        var listaAmigos1=new Array();
                        var listaAmigos2=new Array();

                        var listaSolicitudes=new Array();
                        for (var i = 0; i < misSolicitudes.length; i++) {
                            listaSolicitudes.push(misSolicitudes[i]['friend2email']);
                        }
                        for (var i = 0; i < misAmigos1.length; i++) {
                            listaAmigos1.push(misAmigos1[i]['friend2email']);
                        }
                        for (var i = 0; i < misAmigos2.length; i++) {
                            listaAmigos2.push(misAmigos2[i]['friend1email']);
                        }

                        if (req.session.user=="admin@email.com") {
                            admin=true;
                        }

                        if(req.query.search){
                            response = {
                                users: result.users,
                                pages: pages,
                                currentPage: page,
                                logged: req.session.logged,
                                search: req.query.search,
                                misSolicitudes: listaSolicitudes,
                                misAmigos1: listaAmigos1,
                                misAmigos2: listaAmigos2,
                                admin: admin
                            }
                        }else{
                            response = {
                                users: result.users,
                                pages: pages,
                                currentPage: page,
                                logged: req.session.logged,
                                misAmigos1: listaAmigos1,
                                misAmigos2: listaAmigos2,
                                misSolicitudes: listaSolicitudes,
                                admin: admin
                            }
                        }

                        logger.debug("Listado de usuarios por parte de " + req.session.user);

                        res.render('users/list', response);
                    });

                });
            });

        }).catch((err) => {
            res.send("Se ha producido un error: " + err);
        });
    });

    /**
     * Devuelve la vista con la lista con todos los usuarios del sistema
     * versión administrador.
     */
    app.get('/users/adminList', function(req, res){
        if(req.session.user == 'admin@email.com') {
            usersRepository.getUsers({}, {}).then(users => {
                logger.debug("Listado de usuarios de administrador");
                res.render('users/adminList', {logged: req.session.logged, users: users, admin: true});
            })
        }else{
            res.redirect('/users/list');
        }
    });

    /**
     * Borra los usuarios cuyas ids se reciben en la url
     * separadas por comas
     */
    app.get('/users/remove', function(req, res) {
        let emails = req.query.ids.split(',');
        let counter = 0;
        emails.forEach(async e => {
            await usersRepository.remove({email: e}).then(() => {
                counter++;
                if(counter === emails.length){
                    logger.debug("Borrado de usuarios");
                    res.redirect('/users/adminList');
                }
            });
            // borro toda la informacion q tenga que ver con el usuario
            await friendRequestsRepository.deleteRequest({$or:[{friend1email: e},{friend2email: e}]},{});
            await friendshipsRepository.deleteFriendship({$or:[{friend1email: e},{friend2email: e}]},{});
            await messagesRepository.deleteMessage({$or:[{sender: e},{receiver: e}]},{});
            await postsRepository.deletePost({usuario: e},{});
        });

    });

};