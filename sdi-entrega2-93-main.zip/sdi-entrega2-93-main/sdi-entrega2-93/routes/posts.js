const {ObjectId} = require("mongodb");
module.exports = function (app, usersRepository, postsRepository, logger) {

    /**
     * Devuelve la lista con los posts que pertenecen al usuario
     * recibido en el criterio
     * @param criteria filtro para la BD mongo
     * @param req
     * @param res
     */
    let getOwnPosts = function (criteria, req, res) {
        let options = {sort: {title: 1}}
        if (req.session.user === undefined) {
            res.redirect('users/login');
        } else {

            let page = parseInt(req.query.page);
            if (typeof req.query.page === "undefined" || req.query.page === null || req.query.page === "0") { //Puede no venir el param
                page = 1;
            }
            postsRepository.getPostsPg(criteria, options, page).then(result => {
                let lastPage = result.total / 5
                if (result.total % 5 > 0) { // Sobran decimales
                    lastPage = lastPage + 1;
                }
                let pages = []; // paginas mostrar
                for (let i = page - 2; i <= page + 2; i++) {
                    if (i > 0 && i <= lastPage) {
                        pages.push(i);
                    }
                }
                let response = {
                    posts: result.posts,
                    pages: pages,
                    currentPage: page,
                    logged: req.session.logged
                }
                res.render("posts/ownPosts.twig", response)
            }).catch(error => {
                res.send("There was an error trying to add the songs " + error)
            })
        }
    }

    /**
     * Devuelve la lista con los posts del usuario
     * recibido en el criterio
     * @param criteria filtro para la BD
     * @param req
     * @param res
     * @param user usuario dueño de los posts
     */
    let getPosts = function (criteria, req, res, user) {
        let options = {sort: {title: 1}}
        if (req.session.user === undefined) {
            res.redirect('users/login');
        } else {

            let page = parseInt(req.query.page);
            if (typeof req.query.page === "undefined" || req.query.page === null || req.query.page === "0") { //Puede no venir el param
                page = 1;
            }
            postsRepository.getPostsPg(criteria, options, page).then(result => {
                let lastPage = result.total / 5
                if (result.total % 5 > 0) { // Sobran decimales
                    lastPage = lastPage + 1;
                }
                let pages = []; // paginas mostrar
                for (let i = page - 2; i <= page + 2; i++) {
                    if (i > 0 && i <= lastPage) {
                        pages.push(i);
                    }
                }
                let response = {
                    usuario: user,
                    posts: result.posts,
                    pages: pages,
                    currentPage: page,
                    logged: req.session.logged
                }
                res.render("posts/list.twig", response)
            }).catch(error => {
                res.send("There was an error trying to add the songs " + error)
            })
        }
    }

    /**
     * Devuelve la vista con el formulario para crear posts.
     */
    app.get('/posts/add', function (req, res) {
        res.render("posts/add.twig", {logged: req.session.logged});
    });

    /**
     * Permite crear posts con los datos recibidos en el cuerpo de la petición.
     */
    app.post('/posts/add', async function (req, res) {
        if (req.session.user === undefined) {
            res.redirect("/users/login");
        }
        usersRepository.findUser({email: req.session.user}, {}).then(user => {
            if(req.body.title === "" || req.body.texto === ""){
                res.redirect("/posts/add" +
                    "?message=Titulo o texto vacio"+
                    "&messageType=alert-danger ");
            }else{
                let post = {
                    title: req.body.title,
                    texto: req.body.texto,
                    fecha: new Date(Date.now()).toUTCString(),
                    usuario: user.email
                }
                if (post.title === null || post.title.length === 0 || post.title === "") {
                    res.redirect("/posts/add" + "?message=Este campo no puede ser vacio" + "&messageType=alert-danger");
                }
                if (post.texto === null || post.texto.length === 0 || post.texto === "") {
                    res.redirect("/posts/add" + "?message=Este campo no puede ser vacio" + "&messageType=alert-danger");
                }
                postsRepository.insertPost(post, function (postID) {
                    if(postID===null)   {
                        res.send("Error al crear la publicación");
                    }
                    else    {
                        // res.send("Se hac creado el post con ID " + postID)
                        logger.debug("Nuevo post de " + req.session.user);
                        res.redirect("/posts");
                    }
                })
            }
        });
    })

    /**
     * Devuelve la lista de posts del usuario logeado
     */
    app.get("/posts", async function (req, res) {
        if (req.session.user === undefined) {
            res.redirect("users/login")
        } else {
            await usersRepository.findUser({email: req.session.user}, {})
                .then(user => {
                    let criteria = {usuario: user.email}
                    getOwnPosts(criteria, req, res);
                });
        }
    });

    /**
     * Método que lista las publicaciones de amigos
     */
    app.get('/posts/list/:id', async function (req, res) {
        if (req.session.user === undefined) {
            res.redirect("users/login")
        } else {
            let criteria = {_id: new ObjectId(req.params.id)}
            usersRepository.findUser(criteria).then(user =>{
                criteria = {usuario: user.email}
                getPosts(criteria, req, res, user);
            })
        }

    });


};