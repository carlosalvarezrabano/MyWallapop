const {ObjectId} = require("mongodb");
let my_email = null;

module.exports = function (app, usersRepository, friendshipsRepository, messagesRepository) {

    /**
     * Devuelve una lista con los amigos del usuario logeado
     */
    app.get('/api/v1.0/friends', function(req,res) {
        let filter = {
            $or: [
                {friend1email: my_email},
                {friend2email: my_email},
            ]
        };
        let options = {sort: { friend2email: 1}};
        friendshipsRepository.getFriendsByUser(filter, options).then(friends => {
            res.status(200);
            let usersResult = [];
            usersRepository.getUsers({},{}).then(users => {
                users.forEach(user => {
                   friends.forEach(friendship => {
                      if(user.email !== my_email && friendship.friend1email === user.email){
                          usersResult.push(user);
                      }else if(user.email !== my_email && friendship.friend2email === user.email){
                          usersResult.push(user);
                      }
                   });
                });
                res.send({friends: usersResult});
            }).catch(error => {
                res.status(500);
                res.json({error: "Se ha producido un error al recuperar las amistades." + error.message});
            });
        }).catch(error => {
            res.status(500);
            res.json({ error: "Se ha producido un error al recuperar las amistades." + error.message });
        });
    });

    /**
     * Devuelve una lista con los usuarios logeados cuyo nombre o apellidos
     * coinciden con el parametro de busqueda
     */
    app.get('/api/v1.0/friends/:search', function(req,res) {
        let filter = {
            $or: [
                {friend1email: my_email},
                {friend2email: my_email},
            ]
        };
        let options = {sort: { friend2email: 1}};
        friendshipsRepository.getFriendsByUser(filter, options).then(friends => {
            res.status(200);
            let users = [];
            let criterio, options;
            for (let i = 0; i < friends.length; i++) {
                if(friends[i].friend1email != my_email) {
                    criterio = {email: friends[i].friend1email};
                    options = {projection : {password: 0}};
                } else if(friends[i].friend2email != my_email) {
                    criterio = {email: friends[i].friend2email};
                    options = {projection : {password: 0}};
                }
                usersRepository.findUser(criterio, options).then(user => {
                    if(user != null && (user.name === req.params.search || user.lastname === req.params.search)) {
                        users.push(user);
                    }
                    if(i === friends.length-1) {
                        res.send({friends: users});
                    }
                });
            }
        }).catch(error => {
            res.status(500);
            res.json({ error: "Se ha producido un error al recuperar las amistades." + error.message });
        });
    });

    /**
     * Permite hacer login con usuario y contraseña
     * Devuelve el token de acceso
     */
    app.post('/api/v1.0/users/login', function(req, res) {
        try {
            let securePassword = app.get('crypto').createHmac('sha256', app.get('clave'))
                .update(req.body.password).digest('hex');
            let filter = {
                email: req.body.email,
                password: securePassword
            }
            usersRepository.findUser(filter, {}).then(user => {
                if(user == null) {
                    res.status(401);
                    res.json({
                        message: "Usuario no autorizado",
                        authenticated: false
                    });
                } else {
                    let token = app.get('jwt').sign(
                        {user: user.email, time: Date.now() / 1000},
                        "secreto");
                    my_email = user.email;
                    res.status(200);
                    res.json({
                        message: "Usuario autorizado",
                        authenticated: true,
                        token: token
                    });
                }
            }).catch(error => {
                res.status(401);
                res.json({
                    message: "Se ha producido un error al validar las credenciales",
                    authenticated: false
                });
            })
        } catch(e) {
            res.status(500);
            res.json({
                message: "Se ha producido un error al validar las credenciales",
                authenticated: false
            });
        }
    });

    /**
     * Crea un mensaje cuyos campos son recibidos en el cuerpo de la petición.
     * Si aun no hay conversación entre los usuarios la crea
     */
    app.post('/api/v1.0/messages', function (req, res) {
        try {
            if(req.body.mensaje !== "") {
                let message = {
                    conversationId: null,
                    sender: my_email,
                    receiver: req.body.receiver,
                    text: req.body.mensaje,
                    checked: false,
                    date: Date.now()
                }
                let filter = {
                    $or: [
                        {friend1email: my_email},
                        {friend2email: req.body.receiver},
                        {friend2email: req.session.user},
                        {friend1email: req.body.receiver}
                    ]
                }
                let criterio = {
                    users: {$all: [req.body.receiver, my_email]}
                };

                friendshipsRepository.getFriendsByUser(filter, {}).then(friendship => {
                    if (friendship == null) {
                        res.status(409);
                        res.json({error: "No existe amistad entre emisor y receptor del mensaje"});
                    } else {
                        messagesRepository.findConversation(criterio, {}).then(conversation => {
                            //Si no existe la conversación, sera necesario crearla
                            if (conversation.length === 0) {
                                let conversation = {
                                    users: {$all: [req.body.receiver, my_email]}
                                };
                                messagesRepository.insertConversation(conversation, function (id) {
                                    if (id == null) {
                                        res.status(500);
                                        res.json({
                                            error: "Se ha producido un error creando la conversación"
                                        });
                                    } else {
                                        message.conversacion = id;
                                        messagesRepository.insertMessage(message, function (messageId) {
                                            if (messageId == null) {
                                                res.status(409);
                                                res.json({error: "No se ha podido crear el mensaje."});
                                            } else {
                                                res.status(201);
                                                res.json({
                                                    message: "Mensaje creado correctamente.",
                                                    _id: messageId
                                                });
                                            }
                                        });
                                    }
                                });
                            } else { //Si existe, se añade un mensaje a la conversación
                                message.conversation = conversation._id;
                                messagesRepository.insertMessage(message, function (id) {
                                    if (id == null) {
                                        res.status(500);
                                        res.json({
                                            error: "Se ha producido un error al enviar el mensaje"
                                        });
                                    } else {
                                        res.status(201);
                                        res.json({
                                            enviado: "Se ha enviado el mensaje"
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }else{
                res.status(500);
                res.json({
                    error: "Se ha producido un error al enviar el mensaje"
                });
            }
        } catch (e) {
            res.status(500);
            res.json({error: "Se ha producido un error al intentar crear el mensaje: " + e});
        }
    });

    /**
     * Devuelve los mensajes de la conversacion entre el usuario
     * logeado y el usuario cuyo email es recibido en el cuerpo de la petición
     */
    app.get('/api/v1.0/messages/:friend_id', function(req, res) {
        try {
            let filter1 = {_id: ObjectId(req.params.friend_id)};
            usersRepository.findUser(filter1, {}).then(user => {
                if(user == null) {
                    res.status(404);
                    res.json({error: "ID inválido o no existe"});
                } else {
                    let filter = {
                        $or: [
                            {$and: [{sender: my_email}, {receiver: user.email}]},
                            {$and: [{receiver: my_email}, {sender: user.email}]}
                        ]
                    };
                    messagesRepository.findMessages(filter, {}).then(messages => {
                        if (messages == null) {
                            res.status(500);
                            res.json({error: "Se ha producido un error a recuperar los mensajes."});
                        } else {
                            res.status(200);
                            res.json({messages: messages});
                        }
                    }).catch(error => {
                        res.status(500);
                        res.json({error: "Se ha producido un error a recuperar los mensajes." + error.message});
                    });
                }
            });
        } catch (e) {
            res.status(500);
            res.json({error: "Se ha producido un error"});
        }
    });

    /**
     * Devuelve el usuario cuyo id se recibe por parametro en el endpoint
     */
    app.get('/api/v1.0/users/:id', function(req,res){
        let filter1 = {_id: ObjectId(req.params.id)};
        usersRepository.findUser(filter1, {}).then(user => {
            res.json({user: user})
        });
    });

    /**
     * Marca como leido el mensaje cuyo id se recibe en el cuerpo.
     */
    app.put('/api/v1.0/messages',async function(req, res){
        await messagesRepository.markAsRead(ObjectId(req.body.id), my_email)
        res.sendStatus(200);
    });
}