const {ObjectId} = require("mongodb");
module.exports = function (app, friendRequestsRepository, usersRepository, friendshipsRepository, logger) {

    /**
     * Envia una petición de amistad al usuario cuya id se recibe en el endpoint
     */
    app.get('/friendRequests/add/:id', function(req, res) {
        let filter1 = {_id: ObjectId(req.params.id)}
        let options={}

        if (req.session.user==null) {
            res.status(404);
            res.json({error: "No se puede enviar una peticion sin login"});
        } else {

        usersRepository.findUser(filter1, options).then(user => {
            let friend2email_consult = user.email; //friend2 es el email al que se la envio
            let filter2 = {friend1email: req.session.user, friend2email: friend2email_consult}
            let OK = true
            let message = ""
            let options2 = {}
            friendRequestsRepository.getSolicitudes(filter2, options2).then(requests => {
                if (friend2email_consult == req.session.user) {
                    OK = false;
                    message = "No puedes enviar solicitud a ti mismo";
                } else if (requests.length == 0) { //no envie solicitud
                    let filter3 = {friend1email: req.session.user, friend2email: friend2email_consult}
                    let options3 = {}
                    friendshipsRepository.getFriendsByUser(filter3, options3).then(friendship => {
                        if (friendship.length == 0) { //bien, no es 1 de 2, miro 2 de 1

                            let filter4 = {friend1email: friend2email_consult, friend2email: req.session.user}
                            friendshipsRepository.getFriendsByUser(filter4, options3).then(friendshipInverse => {

                                if (friendshipInverse.length == 0) { //tp hay de 2 a 1
                                    let fr = {
                                        friend1email: req.session.user,
                                        friend2email: friend2email_consult
                                    }
                                    friendRequestsRepository.insertFriendRequest(fr, function (frId) {
                                        logger.debug("Nueva solicitud de " + req.session.user + " y " + friend2email_consult);
                                        res.redirect("/users/list");
                                    });
                                } else {
                                    OK = false;
                                    message = "Ya eres amigo de este usuario"
                                }
                            }).finally(function () {
                                if (!OK) {
                                    res.status(404);
                                    res.json({error: message});
                                }
                            });
                            ;

                        } else {
                            OK = false;
                            message = "Ya eres amigo de este usuario"
                        }
                    }).finally(function () {
                        if (!OK) {
                            res.status(404);
                            res.json({error: message});
                        }
                    });

                } else {
                    OK = false;
                    message = "Ya eres amigo"
                }

            }).finally(function () {
                if (!OK) {
                    res.status(404);
                    res.json({error: message});
                }
            });

        }); }

    });

    /**
     * Devuelve la vista con la lista de peticiones
     * de amistad del usuario logeado.
     */
    app.get('/friendRequests/list', function(req, res) {
        let filter = {friend2email: req.session.user}
        let options={}
        let logged=false
        let page = parseInt(req.query.page); // Es String
        if (typeof req.query.page === "undefined" || req.query.page === null || req.query.page === "0") { //Puede no venir el param
            page = 1;
        }
        friendRequestsRepository.getSolicitudesRecibidas(filter, options, page,function (users, total) {
            if (req.session.user==null) {
                res.redirect("/users/login")
            } else {
                let lastPage = total / 5;
                if (total % 5 > 0) { // Sobran decimales
                    lastPage = lastPage + 1;
                }
                let pages = []; // paginas mostrar
                for (let i = page - 2; i <= page + 2; i++) {
                    if (i > 0 && i <= lastPage) {
                        pages.push(i);
                    }
                }
                logger.debug("Listado de peticiones de " + req.session.user);
                res.render('friendRequests/list', {
                    users: users,
                    pages: pages,
                    currentPage: page,
                    logged: req.session.logged
                });
            }
        });
    });




};