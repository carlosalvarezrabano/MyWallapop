var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var app = express();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Methods", "POST, GET, DELETE, UPDATE, PUT");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, token");
  next();
});


let jwt = require('jsonwebtoken');
app.set('jwt', jwt);

let bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
let expressSession = require('express-session');
app.use(expressSession({
  secret: 'abcdefg',
  resave: true,
  saveUninitialized: true
}));

// BD Mongo
const { MongoClient } = require("mongodb");
const url = 'mongodb+srv://admin:sdi123456@cluster0.ofqd9.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
app.set('connectionStrings', url);

// repositories
let friendshipsRepository = require("./repositories/friendshipsRepository.js");
friendshipsRepository.init(app, MongoClient);
const friendRequestsRepository = require("./repositories/friendRequestsRepository.js");
friendRequestsRepository.init(app, MongoClient);
const postsRepository = require("./repositories/postsRepository.js");
postsRepository.init(app, MongoClient);
const usersRepository = require("./repositories/usersRepository.js");
usersRepository.init(app, MongoClient);
const messagesRepository = require("./repositories/messagesRepository.js");
messagesRepository.init(app, MongoClient);


// para la app normal
const userSessionRouter = require('./routes/userSessionRouter');
const userFriendRouter = require('./routes/userFriendRouter');
const userAdminRouter = require('./routes/userAdminRouter');
app.use("/users/remove", userAdminRouter);
app.use("/users/adminList", userAdminRouter);
app.use("/users/adminList", userSessionRouter);
app.use("/users/remove", userSessionRouter);
app.use("/users/list", userSessionRouter);
app.use("/users/logout", userSessionRouter);
app.use("/posts/*", userSessionRouter);
app.use("/friendships/*", userSessionRouter);
app.use("/friendRequests/*", userSessionRouter);
app.use("/posts/list/:id", userFriendRouter);
// para la api
const userTokenRouter = require('./routes/userTokenRouter');
app.use("/api/v1.0/friends", userTokenRouter);
app.use("/api/v1.0/messages", userTokenRouter);


let crypto = require('crypto');
app.set('clave','abcdefg');
app.set('crypto',crypto);

//log

var log4js = require("log4js");
var logger = log4js.getLogger();
logger.level = "debug"; // default level is OFF - which means no logs at all.

// routers
require("./routes/users.js")(app, usersRepository, friendshipsRepository, friendRequestsRepository, logger, postsRepository, messagesRepository);
require("./routes/index.js")(app);
require("./routes/posts.js")(app, usersRepository, postsRepository, logger);
require("./routes/friendships.js")(app, friendRequestsRepository, usersRepository, friendshipsRepository, logger);
require("./routes/friendRequests.js")(app, friendRequestsRepository, usersRepository, friendshipsRepository, logger);
require("./routes/api/APIv1.0.js")(app, usersRepository, friendshipsRepository, messagesRepository);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'twig');

//app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
