 const {ObjectId} = require("mongodb");
module.exports = {
    mongoClient: null,
    app: null,
    init: function (app, mongoClient) {
        this.mongoClient = mongoClient;
        this.app = app;
    }, insertMessage: function (message, callbackFunction) {
        this.mongoClient.connect(this.app.get('connectionStrings'), function (err, dbClient) {
            if (err) {
                callbackFunction(null);
            } else {
                const database = dbClient.db("sdi-entrega2-93");
                const collectionName = 'messages';
                const messagesCollection = database.collection(collectionName);
                messagesCollection.insertOne(message)
                    .then(result => callbackFunction(result.insertedId))
                    .then(() => dbClient.close())
                    .catch(err => callbackFunction({error: err.message}));
            }
        });
    }, findMessages: async function (filter, options) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'messages';
            const messagesCollection = database.collection(collectionName);
            const messages = await messagesCollection.find(filter, options).toArray();
            client.close()
            return messages;
        } catch (error) {
            throw (error);
        }
    },
    findConversation: async function(filter, options) {
        const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
        const database = client.db("sdi-entrega2-93");
        const collectionName = 'conversations';
        const conversationsCollection = database.collection(collectionName);
        const conversations = await conversationsCollection.find(filter, options).toArray();
        client.close()
        return conversations;
    },
    insertConversation: function(conversation, callbackFunction){
        this.mongoClient.connect(this.app.get('connectionStrings'), function (err, dbClient) {
            if (err) {
                callbackFunction(null);
            } else {
                const database = dbClient.db("sdi-entrega2-93");
                const collectionName = 'conversations';
                const conversationsCollection = database.collection(collectionName);
                conversationsCollection.insertOne(conversation)
                    .then(result => callbackFunction(result.insertedId))
                    .then(() => dbClient.close())
                    .catch(err => callbackFunction({error: err.message}));
            }
        });
    },
    markAsRead: async function(messageId,email){
        const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
        const database = client.db("sdi-entrega2-93");
        const collectionName = 'messages';
        const conversationsCollection = database.collection(collectionName);
        let filter = {_id: {$eq:messageId}, receiver: {$eq:email}}
        conversationsCollection.updateOne(filter, {$set:{checked: true}})
            .then( res => {client.close();return res})
            .catch(err => {return 0})
    },
    deleteMessage: async function(filter, options){
        const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
        const database = client.db("sdi-entrega2-93");
        const collectionName = 'messages';
        const msgCollection = database.collection(collectionName);
        const result = await msgCollection.deleteOne(filter, options);
        client.close();
    }
};