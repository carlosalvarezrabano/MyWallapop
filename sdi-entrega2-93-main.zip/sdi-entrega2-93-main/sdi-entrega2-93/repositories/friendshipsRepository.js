const {ObjectId} = require("mongodb");
module.exports = {
    mongoClient: null,
    app: null,
    init: function (app, mongoClient) {
        this. mongoClient= mongoClient;
        this.app = app;
    }, getFriendsByUser: async function (filter,options) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendships';
            const usersCollection = database.collection(collectionName);
            const friends = await usersCollection.find(filter, options).toArray();
            client.close();
            return friends;
        } catch (error) {
            throw (error);
        }
    }, add: async function (user) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendships';
            const usersCollection = database.collection(collectionName);
            const result = await usersCollection.insertOne(user);
            client.close();
            return result.insertedId;
        } catch (error) {
            throw (error);
        }
    }, deleteFriendship: async function (filter, options) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendships';
            const usersCollection = database.collection(collectionName);
            const result = await usersCollection.deleteOne(filter, options);
            client.close();
        } catch (error) {
            throw (error);
        }
    }

};