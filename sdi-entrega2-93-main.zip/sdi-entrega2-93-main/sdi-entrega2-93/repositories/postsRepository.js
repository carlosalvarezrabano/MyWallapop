 const {ObjectId} = require("mongodb");
module.exports = {
    mongoClient: null,
    app: null,
    init: function (app, mongoClient) {
        this.mongoClient = mongoClient;
        this.app = app;
    }, getPostsPg: async function (filter, options, page) {
        try {
            const limit = 5;
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'posts';
            const postsCollection = database.collection(collectionName);
            const cursor = postsCollection.find(filter, options).sort({date: -1}).
            skip((page - 1) * limit).limit(limit)
            const publicationsCollectionCount = await postsCollection.find(filter, options).count();
            const posts = await cursor.toArray();
            const result = {posts: posts, total: publicationsCollectionCount};
            client.close();
            return result;
        } catch (error) {
            throw (error);
        }
    },insertPost: function (post, callbackFunction) {
        this.mongoClient.connect(this.app.get('connectionStrings'), function (err, dbClient) {
            if (err) {
                callbackFunction(null)
            } else {
                const database = dbClient.db("sdi-entrega2-93");
                const collectionName = 'posts';
                const postsCollection = database.collection(collectionName);  //Comprobar y mirar el nombre de la nueva colección
                postsCollection.insertOne(post)
                    .then(result => callbackFunction(result.insertedId))
                    .then(() => dbClient.close())
                    .catch(err => callbackFunction({error: err.message}));
            }

        })
    },
    deletePost: async function(filter, options){
        const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
        const database = client.db("sdi-entrega2-93");
        const collectionName = 'posts';
        const postsCollection = database.collection(collectionName);
        const result = await postsCollection.deleteOne(filter, options);
        client.close();
    }
};