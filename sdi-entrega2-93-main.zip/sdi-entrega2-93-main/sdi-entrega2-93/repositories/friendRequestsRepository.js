const {ObjectId} = require("mongodb");
module.exports = {
    mongoClient: null,
    app: null,
    init: function (app, mongoClient) {
        this. mongoClient= mongoClient;
        this.app = app;
    },
    getSolicitudes: async function (filter,options) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendRequests';
            const usersCollection = database.collection(collectionName);
            const requests = await usersCollection.find(filter, options).toArray();
            client.close();
            return requests;
        } catch (error) {
            throw (error);
        }
    },
    insertFriendRequest: function (fr, callbackFunction) {
        this.mongoClient.connect(this.app.get('connectionStrings'), function (err, dbClient) {
            if (err) {
                callbackFunction(null)
            } else {
                const database = dbClient.db("sdi-entrega2-93");
                const collectionName = 'friendRequests';
                const songsCollection = database.collection(collectionName);
                songsCollection.insertOne(fr)
                    .then(result => callbackFunction(result.insertedId))
                    .then(() => dbClient.close())
                    .catch(err => callbackFunction({error: err.message}));
            }
        });
    },
    getSolicitudesRecibidas: async function (filter,options,page, callbackFunction) {
        try {
            const limit = 5;
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendRequests';
            const emailsCollection = database.collection(collectionName);
            const usersCollectionCount = await emailsCollection.find(filter, options).count();
            await emailsCollection
                .find(filter, options).skip((page - 1) * limit).limit(limit).toArray(function(err, requests) {
                if (err) {
                    callbackFunction(null);
                }
                const collectionUsersName = 'users';
                const usersCollection = database.collection(collectionUsersName);
                if (requests.length==0) {
                    client.close();
                    callbackFunction(requests);
                } else {
                    let usersList = []
                    let criterio;
                    for (let i = 0; i < requests.length; i++) {
                        criterio = {email: requests[i].friend1email};
                        usersCollection.find(criterio, options).toArray(function (err, usuarios) {
                            if (err) {
                                callbackFunction(null);
                                client.close();
                            } else {
                                usersList[i]=usuarios[0];
                                if (i==requests.length-1) {
                                    client.close();
                                    callbackFunction(usersList, usersCollectionCount);
                                }
                            }

                        });
                    }
                    ;
                }
            });
        } catch (error) {
            throw (error);
        }
    },
    deleteRequest: async function (filter, options) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendRequests';
            const reqsCollection = database.collection(collectionName);
            const result = await reqsCollection.deleteOne(filter, options);
            client.close();
            return result;
        } catch (error) {
            throw (error);
        }
    },
    findRequest: async function (filter, options) {
        try {
            const client = await this.mongoClient.connect(this.app.get('connectionStrings'));
            const database = client.db("sdi-entrega2-93");
            const collectionName = 'friendRequests';
            const reqsCollection = database.collection(collectionName);
            const result = await reqsCollection.findOne(filter, options);
            client.close();
            return result;
        } catch (error) {
            throw (error);
        }
    }

};